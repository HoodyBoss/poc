BUY = 'BUY'
SELL = 'SELL'
LONG = 'LONG'
SHORT = 'SHORT'

# State / trade type / position
STATE_BUY   = 1 # buy = long
STATE_SELL  = 2 # sell = short
STATE_IDLE  = 3

# Trading signal
SIGNAL_BUY                      = 1
SIGNAL_SELL                     = 2
SIGNAL_NONE                     = 3
SIGNAL_CLOSE_AND_WAIT           = 4
#SIGNAL_CLOSE_AND_WAIT_FOR_BUY   = 5
#SIGNAL_CLOSE_AND_WAIT_FOR_SELL  = 6
SIGNAL_SCALE_IN                 = 7
SIGNAL_SCALE_OUT                = 8
SIGNAL_ROLLOVER                 = 9
SIGNAL_MODIFY_STOP_LOSS         = 10
SIGNAL_MODIFY_TAKE_PROFIT       = 11


# Trading action
ACTION_OPEN_BUY                 = 1
ACTION_OPEN_SELL                = 2
ACTION_HOLD_BUY                 = 3
ACTION_HOLD_SELL                = 4
ACTION_CLOSE_BUY                = 5
ACTION_CLOSE_SELL               = 6
ACTION_WAIT                     = 7
#ACTION_WAIT_FOR_BUY             = 8
#ACTION_WAIT_FOR_SELL            = 9
ACTION_CLOSE_BUY_WAIT           = 10
ACTION_CLOSE_SELL_WAIT          = 11
#ACTION_CLOSE_BUY_WAIT_FOR_BUY   = 12
#ACTION_CLOSE_BUY_WAIT_FOR_SELL  = 13
#ACTION_CLOSE_SELL_WAIT_FOR_SELL = 14
#ACTION_CLOSE_SELL_WAIT_FOR_BUY  = 15
ACTION_SCALE_IN_BUY             = 16
ACTION_SCALE_OUT_BUY            = 17
ACTION_SCALE_IN_SELL            = 18
ACTION_SCALE_OUT_SELL           = 19
ACTION_ROLLOVER_BUY             = 20
ACTION_ROLLOVER_SELL            = 21
ACTION_MODIFY_POSITION          = 22
