class InteroperationError(Exception):
    def __int__(self, message):
        super(message)

class ExecutionError(Exception):
    def __int__(self, message):
        super(message)
