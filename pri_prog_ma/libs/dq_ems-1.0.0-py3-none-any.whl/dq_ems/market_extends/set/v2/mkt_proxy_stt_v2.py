import sys

import dq_ems.cons as cons
from dq_ems.error import InteroperationError
from dq_ems.base_ems import BaseMarketProxy


class MarketProxySETSTT(BaseMarketProxy):
    """
    A market proxy to interoperate to SET (Stock Exchange of Thailand) using Settrade SDK.

    NOTE: The market proxy will only check session in: __init__(), load_account_data(), open_trade(), close_trade().
    You can call check_session() explicitly before interoperate to market but should pay attention on performance overhead.
    """

    def __init__(self, trade_account, mkt_connector, mkt_session_cache, params):
        """
        Summary:
            A constructor of MarketProxyCryptoCCXTBinance.
            NOTE:
            1) DO NOT cache mkt_connector object or do not declare as global variable.
            This object must be created every round of triggering (once per trigger).
            2) The mkt_session_cache object must declare as global variable located in the main function.

        Parameters:
            trade_account (dict): a dictionary object comprises required fields for authentication, authorization
                                    and trading (e.g. send order, load account data).
                                    Example fields: API key, API secret, account no., account type
                                    These required fields depend on market/broker/exchange that this MARKET PROXY object
                                    will interoperating to.
            mkt_connector (object): an instance of BaseMarketConnector
            mkt_session_cache (object): an instance of BaseMarketSessionCache
            symbol (dict): key is common name, value is name used by broker or exchange
                                    , for example: { 'S50': 'S50Z22' }
            fee_rate_futures (float): fee rate for futures trade, for example 0.04 = 0.04%
            fee_rate_spot (float): fee rate for spot trade, for example 0.1 = 0.1%
            check_timeout (int): number of milliseconds for check timeout
            exec_wait (int): number of seconds for wating after execute some event, before execute next event
                                    , for example: after open trade, then wait N seconds before send stop order
        """
        super().__init__(trade_account)

        self._investor_object = None
        
        self._mkt_connector = mkt_connector
        self._mkt_session_cache = mkt_session_cache

        try:
            self._fee_rate_tfex = params['fee_rate_tfex']
            self._fee_rate_equity = params['fee_rate_equity']

            self._check_timeout = params['check_timeout']
            self._exec_wait = params['exec_wait']

            self._symbol = params['symbol']
            self._tick_value = params['tick_value']
        except Exception as e:
            raise Exception('MARKET PROXY (STT SDK) -> Could not create MARKET PROXY object -> Invalid params of __init__() error: {}'.format(e))

        self._account_no = trade_account['account_number']
        self._account_type = trade_account['account_type'].upper()
        self._pin = trade_account['pin']

        self._timeframe_map = {'M1': '1m'
                                , 'M3': '3m'
                                , 'M5': '5m'
                                , 'M10': '10m'
                                , 'M15': '15m'
                                , 'M30': '30m'
                                , 'H1': '60m'
                                , 'D1': '1d'
                              }
        # Check market session
        self.check_session()

    #def prepare(self, robot_labels, robot_symbol_infos, symbol_tr_robot_conf):
    #    self.robot_labels = robot_labels
    #    self.robot_symbol_infos = robot_symbol_infos
    #    self.symbol_tr_robot_conf = symbol_tr_robot_conf

    def check_session(self):
        """
        now_timestamp = self.get_timestamp()

        if self._investor_object is None \
                or self._investor_object.MarketData().get_candlestick('.SET', '1d', 1, '', '', False) is None \
                or now_timestamp - self.last_run_ts > self._check_timeout:
            self._investor_object = Investor(app_id=self.__app_id
                                             , app_secret=self.__app_secret
                                             , broker_id=self.config['broker_id']
                                             , app_code=self.__app_code
                                             , is_auto_queue=False)

            self.last_run_ts = now_timestamp
        """
        # Get market session object
        self._investor_object = self._mkt_connector.connect(self._trade_account
                                                            , self._mkt_session_cache
                                                            , check_timeout=self._check_timeout)

        # pass

    # =========================================================================================================
    # BEGIN: Coarse-grained methods
    # =========================================================================================================
    def get_positions(self, exec_params=None):
        return self.get_portfolio(exec_params)

    def get_account_data(self, exec_params=None):
        account_data = {'account_info': None, 'positions': None, 'orders': None, 'trades': None}

        try:
            # self.check_session()

            account_data['account_info'] = self.get_account_info(exec_params)
            account_data['positions'] = self.get_portfolio(exec_params)
            #account_data['orders'] = self.get_orders(exec_params)
            #account_data['trades'] = self.get_trades(exec_params) # This version does not load historical trades
        except Exception:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            print(exc_type)
            print(exc_obj)
            print(exc_tb)
            print(exc_tb.tb_lineno)
            pass

        return account_data

    # =========================================================================================================
    # END: Coarse-grained methods
    # =========================================================================================================

    # =========================================================================================================
    # BEGIN: Fine-grained methods
    # =========================================================================================================
    def open_trade(self, exec_params=None):
        try:
            # self.check_session()
            order_no = {}
            if self._account_type == 'EQUITY':
                acc = self._investor_object.Equity(account_no=self._account_no)
                order_no = self.__place_order_equity(acc, exec_params)
            elif self._account_type == 'DERIVATIVES':
                acc = self._investor_object.Derivatives(account_no=self._account_no)
                order_no = self.__place_order_deriv(acc, exec_params)

            return order_no
        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            print(exc_type)
            print(exc_obj)
            print(exc_tb)
            print(exc_tb.tb_lineno)
            raise InteroperationError('MARKET PROXY (STT SDK) -> Open trade error: {}'.format(e))

    def close_trade(self, exec_params=None):
        try:
            # self.check_session()

            if self._account_type == 'EQUITY':
                acc = self._investor_object.Equity(account_no=self._account_no)
                order_no = self.__place_order_equity(acc, exec_params)
            elif self._account_type == 'DERIVATIVES':
                acc = self._investor_object.Derivatives(account_no=self._account_no)
                order_no = self.__place_order_deriv(acc, exec_params)

            return order_no
        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            print(exc_type)
            print(exc_obj)
            print(exc_tb)
            print(exc_tb.tb_lineno)
            raise InteroperationError('MARKET PROXY (STT SDK) -> Close trade error: {}'.format(e))

    def get_account_info(self, exec_params=None):
        try:
            if self._account_type == 'EQUITY':
                acc = self._investor_object.Equity(account_no=self._account_no)
            elif self._account_type == 'DERIVATIVES':
                acc = self._investor_object.Derivatives(account_no=self._account_no)

            result = acc.get_account_info()
            if result is not None:

                # Add additional fields and map fields to internal schema.
                # You can override this method to use other fields.
                # acc_info['acc_number'] = self._account_no
                # acc_info['balance'] = acc_info['excess_equity'] if self._account_type == 'DERIVATIVES' else acc_info['cash_balance']

                return result
            else:
                return None
        except Exception as e:
            raise InteroperationError('MARKET PROXY (STT SDK) -> Get account info error: {}'.format(e))

    def get_portfolio(self, exec_params=None):
        try:
            if self._account_type == 'EQUITY':
                acc = self._investor_object.Equity(account_no=self._account_no)
            elif self._account_type == 'DERIVATIVES':
                acc = self._investor_object.Derivatives(account_no=self._account_no)

            positions = []

            result = acc.get_portfolios()
            # if result is not None:
            #     for pos in result:
            #         # Add additional fields to original position data loaded from market.
            #         # For original position fields and meaning, please refer to Settrade Open API
            #         # (https://developer.settrade.com/open-api/api-reference/reference/sdk/python/investor-derivatives/getPortfolio)
            #         # Additional fields are trade_type, quantity, symbol_name, stop_loss, take_profit, robot_name, label.

            #         # NOTE: 'entry_time' is saved in position_entry_mem in BaseExecRobot in base_exec.py
            #         # The 'entry_time' is saved after opened new position immediately.
            #         print("Pos>>>>", pos)
            #         pos['com_fee'] = 0.0
            #         pos['entry_price'] = 0.0
            #         pos['unrealized_profit'] = 0.0

            #         if self._account_type == 'DERIVATIVES':
            #             if pos['actual_long_position'] > 0:
            #                 pos['trade_type'] = cons.BUY
            #                 pos['quantity'] = pos['actual_long_position']
            #                 pos['entry_price'] = pos['start_long_price'] if 'start_long_price' in pos else 0.0
            #                 pos['avg_price'] = pos['long_avg_price'] if 'long_avg_price' in pos else 0.0
            #                 pos['market_price'] = pos['market_price'] if 'market_price' in pos else 0.0

            #                 pos['unrealized_profit'] = self.cal_unreal_profit(self._account_type
            #                                                                   , pos['avg_price']
            #                                                                   , pos['market_price']
            #                                                                   , pos['quantity']
            #                                                                   , 'LONG')
            #             elif pos['actual_short_position'] > 0:
            #                 pos['trade_type'] = cons.SELL
            #                 pos['quantity'] = pos['actual_long_position']
            #                 pos['entry_price'] = pos['start_short_price'] if 'start_long_price' in pos else 0.0
            #                 pos['avg_price'] = pos['short_avg_price'] if 'short_avg_price' in pos else 0.0
            #                 pos['market_price'] = pos['market_price'] if 'market_price' in pos else 0.0
            #                 pos['unrealized_profit'] = self.cal_unreal_profit(self._account_type
            #                                                                   , pos['avg_price']
            #                                                                   , pos['market_price']
            #                                                                   , pos['quantity']
            #                                                                   , 'SHORT')

            #             if pos['entry_price'] > 0:
            #                 fee_rate = float(self.config['fee_rate_tfex'])
            #                 pos['com_fee'] = self.cal_fee(self._account_type, pos['quantity'], fee_rate)

            #         pos['symbol_name'] = pos['symbol']
            #         pos['stop_loss'] = 0.0
            #         pos['take_profit'] = 0.0

            #         #pos['label'] = xxx

            #         positions.append(pos)

            return result

        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            raise InteroperationError('MARKET PROXY (STT SDK) -> Get portfolio (all current positions) error: {}, line:{}'.format(e, exc_tb.tb_lineno))

    def get_order(self, exec_params=None):
        try:
            if self._account_type == 'EQUITY':
                acc = self._investor_object.Equity(account_no=self._account_no)
            elif self._account_type == 'DERIVATIVES':
                acc = self._investor_object.Derivatives(account_no=self._account_no)

            result = acc.get_order(order_no=exec_params['order_no'])
            if result is not None and result['success'] == True:
                return result['data']
            else:
                return None
        except Exception as e:
            raise InteroperationError('MARKET PROXY (STT SDK) -> Get order error: {}'.format(e))

    def get_orders(self, exec_params=None):
        try:
            if self._account_type == 'EQUITY':
                acc = self._investor_object.Equity(account_no=self._account_no)
            elif self._account_type == 'DERIVATIVES':
                acc = self._investor_object.Derivatives(account_no=self._account_no)

            orders = []

            if 'symbol' in exec_params:
                symbols = [exec_params['symbol']] # convert to list
            elif 'symbols' in exec_params:
                symbols = exec_params['symbols']
            else:
                symbols = []

            order_status_list = exec_params['status_list'].upper() if 'status_list' in exec_params else []
            if order_status_list is None:
                order_status_list = []

            # Load orders
            result = acc.get_orders()

            if result is not None:
                # all_orders = result['data']

                for order in result:
                    if len(symbols) > 0:
                        if order['symbol'].upper() in symbols:
                            if len(order_status_list) > 0:
                                if order['status'].upper() in order_status_list:
                                    orders.append(order)
                            else:
                                orders.append(order)
                    else:
                        if len(order_status_list) > 0:
                            if order['status'].upper() in order_status_list:
                                orders.append(order)
                        else:
                            orders.append(order)

            return orders
        except Exception as e:
            raise InteroperationError('MARKET PROXY (STT SDK) -> Get order list error: {}'.format(e))

    def modify_order(self, exec_params=None):
        return NotImplementedError

    def cancel_order(self, exec_params=None):
        try:
            if self._account_type == 'EQUITY':
                acc = self._investor_object.Equity(account_no=self._account_no)
            else:
                acc = self._investor_object.Derivatives(account_no=self._account_no)

            result = acc.cancel_order(order_no=exec_params['order_no'], pin=self._pin)
            print("Cancel order result>>>", result)
            # if result is not None:
            #     return True
            # elif result is self._account_type == 'DERIVATIVES':
            #     return False
            return result
        except Exception as e:
            raise InteroperationError('MARKET PROXY (STT SDK) -> Cancel order error: {}'.format(e))

    def cancel_orders(self, exec_params=None):
        try:
            if self._account_type == 'EQUITY':
                acc = self._investor_object.Equity(account_no=self._account_no)
            else:
                acc = self._investor_object.Derivatives(account_no=self._account_no)

            if 'orders_no' in exec_params and len(exec_params['orders_no']) > 0:
                result = acc.cancel_orders(orders_no=exec_params['orders_no'], pin=self._pin)
                if result is not None and result['success'] == True:
                    return True
                else:
                    return False
            else:
                raise Exception('Invalid orders_no')
        except Exception as e:
            raise InteroperationError('MARKET PROXY (STT SDK) -> Cancel multiple orders error: {}'.format(e))
    # =========================================================================================================
    # END: Fine-grained methods
    # =========================================================================================================

    # =========================================================================================================
    # BEGIN: Additional methods
    # =========================================================================================================
    def get_trades(self, exec_params=None):
        try:
            if self._account_type == 'EQUITY':
                acc = self._investor_object.Equity(account_no=self._account_no)
            elif self._account_type == 'DERIVATIVES':
                acc = self._investor_object.Derivatives(account_no=self._account_no)

            result = acc.get_trades()
            if result is not None:
                return result
            else:
                return None
        except Exception as e:
            raise InteroperationError('MARKET PROXY (STT SDK) -> Get trade list error: {}'.format(e))

    def get_candlestick(self, symbol, interval, limit, start=None, end=None, normalized=True):
        """Returns candlesticks of specified symbol and other parameters
        :param symbol: (string) symbol
        :param interval: (string) time frame, such as 1m, 5m, 15m, 30m, 60m, 1d,...
        :param limit: (int) number of candlesticks, not exceed 1,000
        :param start: (string) start date time, example format -> 2021-02-01T11:00:00
        :param end: (string) end date time, example format -> 2021-02-01T11:00:00
        :param normalized: (boolean) normalize requirement
        :return: dictionary of many lists, format: {'time':[], 'open':[], 'high':[], 'low':[], 'close':[], 'volume':[]}
        *NOTE: format of time is Unix timestamp
        """
        try:
            market = self._investor_object.MarketData()

            timeframe = interval
            if interval in list(self._timeframe_map.keys()):
                timeframe = self._timeframe_map[interval]
            
            #for v2
            if start is not None and end is not None:
                result = market.get_candlestick(symbol=symbol, interval=timeframe, limit=limit, start=start, end=end, normalized=normalized)
            else:
                result = market.get_candlestick(symbol=symbol, interval=timeframe, limit=limit, normalized=normalized)

            if result is not None and 'lastSequence' in result:
                return result
            else:
                return None
        except Exception as e:
            raise InteroperationError('MARKET PROXY (STT SDK) -> Get candlestick error: {}'.format(e))

    def cal_fee(self, account_type, pos_size, fee_rate, price=None):
        fee = 0.0
        if account_type == 'DERIVATIVES':
            fee = pos_size * fee_rate
        return fee

    def cal_unreal_profit(self, account_type, avg_price, market_price, pos_size, side=None):
        unreal_profit = 0.0
        if avg_price != 0 and market_price != 0:
            if account_type == 'DERIVATIVES':
                if side == 'LONG':
                    unreal_profit = round((market_price - avg_price) * pos_size * self._tick_value, 2)
                elif side == 'SHORT':
                    unreal_profit = round((avg_price - market_price) * pos_size * self._tick_value, 2)
            elif account_type == 'EQUITY':
                unreal_profit = round((market_price - avg_price) * pos_size, 2)

        return unreal_profit

    # PRIVATE METHODS =========================================================================
    def __place_order_deriv(self, acc, order):
        if 'stop_price' in order and order['stop_price'] > 0:
            result = acc.place_order(symbol=order['symbol']
                                         , price=order['price']
                                         , volume=order['volume']
                                         , side=order['side']
                                         , position=order['position']
                                         , pin=self._pin
                                         , price_type=order['price_type']
                                         , stop_condition=order['stop_condition']
                                         , stop_price=order['stop_price']
                                         , stop_symbol=order['stop_symbol']
                                         , bypass_warning=True)
        else:
            result = acc.place_order(symbol=order['symbol']
                                         , price=order['price']
                                         , volume=order['volume']
                                         , side=order['side']
                                         , position=order['position']
                                         , pin=self._pin
                                         , price_type=order['price_type']
                                         , bypass_warning=True)
        
        if result is not None:
            return result
        else:
            return None

    def __place_order_equity(self, acc, order):
        result = acc.place_order(order['symbol']
                                         , order['price']
                                         , order['volume']
                                         , order['side']
                                         , order['position']
                                         , self._pin
                                         , order['price_type']
                                         , bypass_warning=True)

        if result is not None:
            return result
        else:
            return None
    # =========================================================================================================
    # END: Additional methods
    # =========================================================================================================



class Synchronizer():

    def __init__(self, trade_account, mkt_connector, mkt_session_cache, params={}):
        self.__market_proxy = MarketProxySETSTT(trade_account, mkt_connector, mkt_session_cache, params)

    def call(self, q, lock, method, exec_params):
        result = None

        def get_positions(exec_params):
            result = self.__market_proxy.get_positions(exec_params)
            return result

        def load_account_data(exec_params):
            result = self.__market_proxy.load_account_data(exec_params)
            return result

        def open_trade(exec_params):
            result = self.__market_proxy.open_trade(exec_params)
            return result

        def close_trade(exec_params):
            result = self.__market_proxy.close_trade(exec_params)
            return result

        def get_account_info(exec_params):
            result = self.__market_proxy.get_account_info(exec_params)
            return result

        def get_portfolio(exec_params):
            result = self.__market_proxy.get_portfolio(exec_params)
            return result

        def get_order(exec_params):
            result = self.__market_proxy.get_order(exec_params)
            return result

        def get_orders(exec_params):
            result = self.__market_proxy.get_orders(exec_params)
            return result

        def modify_order(exec_params):
            result = self.__market_proxy.modify_order(exec_params)
            return result

        def cancel_order(exec_params):
            result = self.__market_proxy.cancel_order(exec_params)
            return result

        def cancel_orders(exec_params):
            result = self.__market_proxy.cancel_orders(exec_params)
            return result

        def get_trades(exec_params):
            result = self.__market_proxy.get_trades(exec_params)
            return result

        def get_candlestick(exec_params):
            result = self.__market_proxy.get_candlestick(exec_params['symbol']
                                                            , exec_params['interval']
                                                            , exec_params['limit']
                                                            , exec_params['start']
                                                            , exec_params['end']
                                                            , exec_params['normalized'])
            return result

        def cal_fee(exec_params):
            price = exec_params['price'] if 'price' in exec_params else None
            result = self.__market_proxy.cal_fee(exec_params['account_type']
                                                    , exec_params['pos_size']
                                                    , exec_params['fee_rate']
                                                    , price)
            return result

        def cal_unreal_profit(exec_params):
            side = exec_params['side'] if 'side' in exec_params else None
            result = self.__market_proxy.cal_unreal_profit(exec_params['account_type']
                                                            , exec_params['avg_price']
                                                            , exec_params['market_price']
                                                            , exec_params['pos_size']
                                                            , side)
            return result

        try:
            lock.acquire()
            result = eval(method)(exec_params)
            q.put(result)
        finally:
            lock.release()
