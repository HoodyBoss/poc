import ccxt
from dq_ems.base_ems import BaseMarketConnector

from settrade_v2 import Investor


class MarketConnectorSTT(BaseMarketConnector):

    def _get_mkt_session_status(self, mkt_session, params=None):
        status = None
        print("#### mkt_session>>>", mkt_session)
        if mkt_session is not None:
            status = 'ok' #mkt_session.status['status']
        return status

    def _create_mkt_session(self, trade_account, check_timeout, params=None):
        mkt_session = Investor(app_id=trade_account['app_id']
                                             , app_secret=trade_account['app_secret']
                                             , broker_id=trade_account['broker_id']
                                             , app_code=trade_account['app_code']
                                             , is_auto_queue=True)


        return mkt_session
