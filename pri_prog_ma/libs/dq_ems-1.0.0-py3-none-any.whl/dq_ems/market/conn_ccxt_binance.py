import ccxt
from dq_ems.base_ems import BaseMarketConnector


class MarketConnectorCCXTBinance(BaseMarketConnector):

    def _get_mkt_session_status(self, mkt_session, params=None):
        status = None
        if mkt_session is not None:
            status = mkt_session.status['status']
        return status

    def _create_mkt_session(self, trade_account, check_timeout, params=None):
        # print("########################################### Begin Connect market ###########################################")
        # print("Exchange:::", trade_account['exchange_id'])
        # print("Api Key:::", trade_account['api_key'])
        # print("Api Secret:::", trade_account['api_secret'])
        exchange_class = getattr(ccxt, trade_account['exchange_id'])
        mkt_session = exchange_class({
                'apiKey': trade_account['api_key']
                , 'secret': trade_account['api_secret']
                , 'timeout': check_timeout
                , 'enableRateLimit': True
                , 'options': {
                    'defaultType': 'future' if trade_account['account_type'].lower() == 'futures' else 'spot'
                }
        })

        sandbox_mode = params['sandbox_mode'] if 'sandbox_mode' in params else None

        if sandbox_mode == True:
            mkt_session.set_sandbox_mode(True)

        
        mkt_session.load_markets()
        # print("########################################### End Load Market ###########################################")

        return mkt_session
