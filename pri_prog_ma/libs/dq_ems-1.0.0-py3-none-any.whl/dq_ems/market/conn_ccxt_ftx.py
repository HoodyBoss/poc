import ccxt
from dq_ems.base_ems import BaseMarketConnector


class MarketConnectorCCXTFTX(BaseMarketConnector):

    def _get_mkt_session_status(self, mkt_session, params=None):
        status = None
        if mkt_session is not None:
            status = mkt_session.status['status']
        return status

    def _create_mkt_session(self, trade_account, check_timeout, params=None):
        exchange_class = getattr(ccxt, trade_account['exchange_id'])
        mkt_session = exchange_class({
                'apiKey': trade_account['api_key']
                , 'secret': trade_account['api_secret']
                , 'timeout': check_timeout
                , 'enableRateLimit': True
                , 'options': {
                    'defaultType': 'future' if trade_account['account_type'].lower() == 'futures' else 'spot'
                }
        })

        sandbox_mode = params['sandbox_mode'] if 'sandbox_mode' in params else None

        if sandbox_mode == True:
            mkt_session.set_sandbox_mode(True)
        is_sub_account = trade_account['is_sub_account'] if 'is_sub_account' in trade_account else None
        
        if is_sub_account is not None and is_sub_account.upper() == "Y":
            mkt_session.headers = {
                         'FTX-SUBACCOUNT': trade_account['account_number'],
                         }

        mkt_session.load_markets()

        return mkt_session
