from dq_ems.base_ems import BaseTradeAccountLoader

class DefaultTradeAccountLoader(BaseTradeAccountLoader):

    def load(self, trade_account_id, params=None):
        trade_account = {}

        if type(params) is dict:
            trade_account['id'] = trade_account_id

            if params['market'].upper() == 'CRYPTO':
                trade_account['exchange_id'] = params['exchange_id'].lower()
                trade_account['account_number'] = params['account_number']
                trade_account['account_type'] = params['account_type']
                trade_account['api_key'] = params['api_key']
                trade_account['api_secret'] = params['api_secret']

            elif params['market'].upper() == 'SET':
                trade_account['broker_id'] = params['broker_id']
                trade_account['account_number'] = params['account_number']
                trade_account['account_type'] = params['account_type']
                trade_account['pin'] = params['pin']
                trade_account['app_id'] = params['app_id']
                trade_account['app_secret'] = params['app_secret']
                trade_account['app_code'] = params['app_code']

        return trade_account
