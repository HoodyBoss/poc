from dq_ems.base_ems import BaseTradeAccountLoader
import json

class DeepOceanTradeAccountLoader(BaseTradeAccountLoader):

    def load(self, trade_account_id, params=None):
        trade_account = {}
        params = self.get_trade_acc_info_from_secret_manager(trade_account_id)
        
        if type(params) is dict and "flag" in params and params["flag"] == "success":
            
            trade_account['flag'] = "success"
            trade_account['id'] = trade_account_id
            ## call get trade account info from secret manager api
            params = json.loads(params["data"])
            if params['market'].upper() == 'CRYPTO':
                trade_account['exchange_id'] = params['exchange_id'].lower()
                trade_account['account_number'] = params['account_number']
                trade_account['account_type'] = params['account_type']
                trade_account['api_key'] = params['api_key']
                trade_account['api_secret'] = params['api_secret']
                trade_account['is_sub_account'] = params['is_sub_account']

            elif params['market'].upper() == 'SET':
                trade_account['broker_id'] = params['broker_id']
                trade_account['account_number'] = params['account_number']
                trade_account['account_type'] = params['account_type']
                trade_account['pin'] = params['pin']
                trade_account['app_id'] = params['app_id']
                trade_account['app_secret'] = params['app_secret']
                trade_account['app_code'] = params['app_code']
        else:
            trade_account = params

        return trade_account

    def get_trade_acc_info_from_secret_manager(self, secret_id ):
        import requests
        import json
        import os
        
        API_GATEWAY_SECRET_MANAGER_ENDPOINT = os.getenv("API_GATEWAY_SECRET_MANAGER_ENDPOINT")
        API_GATEWAY_SECRET_MANAGER_KEY = os.getenv("API_GATEWAY_SECRET_MANAGER_KEY")
        # ret = requests.post( f'{API_GATEWAY_SECRET_MANAGER_ENDPOINT}/getTradeApi', json={"secret_id": trade_account_id}, headers={"Content-Type":"applicaton/json", "x-api-key": API_GATEWAY_SECRET_MANAGER_KEY})
        ret = requests.get( f'{API_GATEWAY_SECRET_MANAGER_ENDPOINT}/secrets/secret_id', params={"secret_id": secret_id}, headers={"Content-Type":"applicaton/json", "x-api-key": API_GATEWAY_SECRET_MANAGER_KEY})
        trade_account_info = json.loads(ret.text)
        return trade_account_info