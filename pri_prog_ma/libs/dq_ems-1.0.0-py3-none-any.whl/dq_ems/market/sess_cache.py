#import redis
#import pickle
from dq_ems.base_ems import BaseMarketSessionCache


class DefaultMarketSessionCache(BaseMarketSessionCache):

    def __init__(self):
        self.__cache = {}

    def set(self, session_key, session_val, last_run_ts=0):
        value = {
            'session_key' : session_key
            , 'session_val' : session_val
            , 'last_run_ts' : last_run_ts
        }

        self.__cache[session_key] = value

    def get(self, session_key):
        mkt_session = None
        try:
            mkt_session = self.__cache[session_key]
        except:
            pass
        return mkt_session

    """
    def __init__(self, redis_config):
        if 'password' in redis_config and redis_config['password'] is not None:
            self.__cache = redis.Redis(host=redis_config['host']
                                    , port=redis_config['port']
                                    , password=redis_config['password'])
            
        else:
            self.__cache = redis.Redis(host=redis_config['host']
                                    , port=redis_config['port'])

    def set(self, session_key, session_val, last_run_ts=0):
        value = {
            'session_key' : session_key
            , 'session_val' : session_val
            , 'last_run_ts' : last_run_ts
        }

        # Serialize dictionary object before set to Redis
        self.__cache.set(session_key, pickle.dumps(value))

    def get(self, session_key):
        deserialized_mkt_session = None
        serialized_mkt_session = self.__cache.get(session_key)
        if serialized_mkt_session is not None:
            # Deserialize dictionary object
            deserialized_mkt_session = pickle.loads(serialized_mkt_session)
        return deserialized_mkt_session
    """
