import time
import sys

import dq_ems.cons as cons
from dq_ems.error import InteroperationError
from dq_ems.base_ems import BaseMarketProxy

from deepocean_trade_api import TradeType

class MarketProxyCryptoCCXTFTX(BaseMarketProxy):
    """
    Summary:
        # =========================================================================================================
        #
        # THE CURRENT VERSION USES CCXT V.1.93.3
        #
        # =========================================================================================================
        A MARKET PROXY to interoperate to crypto exchange using CCXT python library.
        This class works with FTX as default. If use other exchange, please extend this class and override some functions.
    
        NOTE: The MARKET PROXY will only check session in: __init__(), load_account_data(), open_trade(), close_trade().
        You can call check_session() explicitly before access market but should pay attention on performance overhead.
    
    RULES:
        1. 1 symbol per 1 trading robot
        2. 1 trading model per 1 position (long or short)
    """

    def __init__(self, trade_account, mkt_connector, mkt_session_cache, params):
        """
        Summary:
            A constructor of MarketProxyCryptoCCXTFTX.
            NOTE:
            1) DO NOT cache mkt_connector object or do not declare as global variable.
            This object must be created every round of triggering (once per trigger).
            2) The mkt_session_cache object must declare as global variable located in the main function.

        Parameters:
            trade_account (dict): a dictionary object comprises required fields for authentication, authorization
                                    and trading (e.g. send order, load account data).
                                    Example fields: API key, API secret, account no., account type
                                    These required fields depend on market/broker/exchange that this MARKET PROXY object
                                    will interoperating to.
            mkt_connector (object): an instance of BaseMarketConnector
            mkt_session_cache (object): an instance of BaseMarketSessionCache
            symbols (dict): key is common name, value is name used by broker or exchange
                                    , for example: { 'BTCUSD': 'BTC/USDT', 'ETHUSD': 'ETH/USDT' }
            sandbox_mode (boolean): True is running in sandbox mode, False is live trading mode
            fee_rate_futures (float): fee rate for futures trade, for example 0.04 = 0.04%
            fee_rate_spot (float): fee rate for spot trade, for example 0.1 = 0.1%
            check_timeout (int): number of milliseconds for check timeout
            exec_wait (int): number of seconds for wating after execute some event, before execute next event
                                    , for example: after open trade, then wait N seconds before send stop order
        """
        
        super().__init__(trade_account)

        self._exchange = None

        self._mkt_connector = mkt_connector
        self._mkt_session_cache = mkt_session_cache

        try:
            self._fee_rate_futures = params['fee_rate_futures']
            self._fee_rate_spot = params['fee_rate_spot']

            self._sandbox_mode = params['sandbox_mode']

            self._check_timeout = params['check_timeout']
            self._exec_wait = params['exec_wait']

            self._symbol = params['symbol']

            self._rec_window = params['rec_window']
        except Exception as e:
            raise Exception('MARKET PROXY (CCXT-FTX) -> Could not create MARKET PROXY object -> Invalid params of __init__() error: {}'.format(e))

        self._account_no = trade_account['account_number']
        self._account_type = trade_account['account_type']

        self._timeframe_map = {'M1': '1m'
                                , 'M3': '3m'
                                , 'M5': '5m'
                                , 'M15': '15m'
                                , 'M30': '30m'
                                , 'H1': '1h'
                                , 'H2': '2h'
                                , 'H4': '4h'
                                , 'D1': '1d'
                              }
        # Check market session
        self.check_session()

    def check_session(self):
        # Get market session object
        self._exchange = self._mkt_connector.connect(self._trade_account
                                                    , self._mkt_session_cache
                                                    , check_timeout=self._check_timeout
                                                    , params={'sandbox_mode': self._sandbox_mode})

    # =========================================================================================================
    # BEGIN: Coarse-grained methods
    # =========================================================================================================
    def get_positions(self, exec_params=None):
        return self.get_portfolio(exec_params)

    def get_account_data(self, exec_params=None):
        account_data = {'account_info': None, 'positions': None, 'orders': None, 'trades': None}

        try:
            self.check_session()
            
            exec_params = {}
            exec_params['decorate_position'] = True
            exec_params['type'] = 'OPEN' # order type to load order

            # NOTE: This operation will get position from loaded account info. So, the positions in balance use specific fields of exchange,
            # not CCXT unified fields.
            # Design rationale:
            # To improve performance (speed) by reducing latency from many calls when execution starting.
            # At this point the execution usually loads many data: account info, position, orders,... before send them to trading robots.

            account_data['account_info'] = self.get_account_info(exec_params)
            account_data['positions'] = account_data['account_info']['info']['positions']
            #account_data['orders'] = self.get_orders(exec_params)
            #account_data['trades'] = self.get_trades(exec_params) # This version does not load historical trades
        except Exception:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            print(exc_type)
            print(exc_obj)
            print(exc_tb)
            print(exc_tb.tb_lineno)
            pass

        return account_data

    # =========================================================================================================
    # END: Coarse-grained methods
    # =========================================================================================================

    # =========================================================================================================
    # BEGIN: Fine-grained methods
    # =========================================================================================================
    def open_trade(self, exec_params=None):
        """Open new trade or new order and return order info but returned order may be None because of delaying.
        """
        try:
            self.check_session()

            exchange_symbol = self._symbol[exec_params['symbol']]

            order = None
            if 'stop_loss_price' in exec_params:
                try:
                    order = self._exchange.create_order(symbol=exchange_symbol
                                                        , type='STOP_MARKET'
                                                        , side=exec_params['side']
                                                        , amount=exec_params['amount']
                                                        , params={
                                                            'positionSide': exec_params['positionSide']
                                                            , 'stopPrice': exec_params['stop_loss_price']
                                                            , 'clientOrderId': exec_params['clientOrderId']
                                                            , 'recvWindow': self._rec_window
                                                        })
                except Exception as ex:
                    ex_msg = str(ex).lower()
                    # error code 4015 -> Client order id is not valid. This means there is already existing stop order.
                    # error code 2021 -> Order would immediately trigger.
                    #                    This means SL price is too close to market price
                    #                    or Sl price is higher than market price for Long position
                    #                    or SL price is lower than market price for short position.
                    if ('code' in ex_msg and '4015' in ex_msg) \
                            or ('code' in ex_msg and '2021' in ex_msg):
                        pass

            elif 'take_profit_price' in exec_params:
                try:
                    order = self._exchange.create_order(symbol=exchange_symbol
                                                        , type='TAKE_PROFIT_MARKET'
                                                        , side=exec_params['side']
                                                        , amount=exec_params['amount']
                                                        , params={
                                                            'positionSide': exec_params['positionSide']
                                                            , 'stopPrice': exec_params['take_profit_price']
                                                            , 'clientOrderId': exec_params['clientOrderId']
                                                            , 'recvWindow': self._rec_window
                                                        })
                except Exception as ex:
                    ex_msg = str(ex).lower()
                    # error code 4015 -> Client order id is not valid. This means there is already existing stop order.
                    # error code 2021 -> Order would immediately trigger.
                    #                    This means TP price is too close to market price
                    #                    or TP price is lower than market price for Long position
                    #                    or TP price is higher than market price for short position.
                    if ('code' in ex_msg and '4015' in ex_msg) \
                            or ('code' in ex_msg and '2021' in ex_msg):
                        pass

            elif exec_params['type'] == TradeType.LIMIT.value:
                order = self._exchange.create_order(symbol=exchange_symbol
                                                    , type=exec_params['type']
                                                    , side=exec_params['side']
                                                    , amount=exec_params['amount']
                                                    , price=exec_params['price']
                                                    , params={
                                                         'clientOrderId': exec_params['clientOrderId']
                                                        , 'recvWindow': self._rec_window
                                                    })
            else:
                order = self._exchange.create_order(symbol=exchange_symbol
                                                    , type=exec_params['type']
                                                    , side=exec_params['side']
                                                    , amount=exec_params['amount']
                                                    , price=exec_params['price']
                                                    , params={
                                                         'clientOrderId': exec_params['clientOrderId']
                                                        , 'recvWindow': self._rec_window
                                                    })
            return order
        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            print(exc_type)
            print(exc_obj)
            print(exc_tb)
            print(exc_tb.tb_lineno)
            raise InteroperationError('MARKET PROXY (CCXT-FTX) -> Open trade error: {}'.format(e))

    def close_trade(self, exec_params=None):
        """Close trade and return order info but returned order may be None because of delaying.
        """
        try:
            self.check_session()

            exchange_symbol = self._symbol[exec_params['symbol']]

            order = self._exchange.create_order(symbol=exchange_symbol
                                                , type=exec_params['type']
                                                , side=exec_params['side']
                                                , amount=exec_params['amount']
                                                , params={
                                                        'positionSide': exec_params['positionSide']
                                                        , 'clientOrderId': exec_params['clientOrderId']
                                                        , 'recvWindow': self._rec_window
                                                })
            return order
        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            print(exc_type)
            print(exc_obj)
            print(exc_tb)
            print(exc_tb.tb_lineno)
            raise InteroperationError('MARKET PROXY (CCXT-FTX) -> Close trade error: {}'.format(e))

    def get_account_info(self, exec_params=None):
        try:
            balance_temp = self._exchange.fetch_balance({'recvWindow': self._rec_window})

            if balance_temp is not None:
                acc_info = {}
                futures_position_mode = self._exchange.fapiPrivate_get_positionside_dual({'recvWindow': self._rec_window})

                acc_info['acc_number'] = self._account_no
                acc_info['account_type'] = self._account_type
                acc_info['futures_position_mode'] = 'HEDGE' if futures_position_mode['dualSidePosition'] else 'ONE-WAY'
                acc_info['balance'] = float(balance_temp['info']['availableBalance'])
                acc_info['equity'] = float(balance_temp['info']['availableBalance']) + float(balance_temp['info']['totalUnrealizedProfit'])
                acc_info['info'] = balance_temp['info']
                acc_info['info']['assets'] = self.__get_valid_values(balance_temp['info']['positions'], 'initialMargin')
                
                if exec_params is not None and exec_params['decorate_position'] == True:
                    positions = self.__get_valid_values(balance_temp['info']['positions'], 'positionAmt', check_sign=True)
                    # Decorate fields and build dictionary of positions, key is robot name, value is position dict
                    acc_info['info']['positions'] = self.__decorate_position(positions)
            else:
                acc_info = None

            return acc_info
        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            print(exc_type)
            print(exc_obj)
            print(exc_tb)
            print(exc_tb.tb_lineno)
            raise InteroperationError('MARKET PROXY (CCXT-FTX) -> Get account info error: {}'.format(e))

    def get_portfolio(self, exec_params=None):
        """Returns active positions in dictionary, key is robot name, value is position dictionary
        """
        try:
            balance = self._exchange.fetch_balance({'recvWindow': self._rec_window})
            positions = self.__get_valid_values(balance['info']['positions'], 'positionAmt', check_sign=True)

            # Decorate fields and build dictionary of position
            tr_bot_positions = self.__decorate_position(positions)
            return tr_bot_positions
        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            print(exc_type)
            print(exc_obj)
            print(exc_tb)
            raise InteroperationError('MARKET PROXY (CCXT-FTX) -> Get portfolio error: {}'.format(e))

    def get_order(self, exec_params=None):
        try:
            exchange_symbol = self._symbol[exec_params['symbol']]
            order = self._exchange.fetch_order(exec_params['order_no'], symbol=exchange_symbol, params={'recvWindow': self._rec_window})

            if order is not None:
                self.__decorate_order(order)
                return order
            else:
                return None
        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            print(exc_type)
            print(exc_obj)
            print(exc_tb)
            print(exc_tb.tb_lineno)
            raise InteroperationError('MARKET PROXY (CCXT-FTX) -> Get order error: {}'.format(e))

    def get_orders(self, exec_params=None):
        """Returns list of order. For exec_params should define two fields:
        - symbol or symbols (list)
        - type can be 'OPEN' (open orders), 'CLOSED' (closed orders), if not specifiy, will load allo orders
        """
        try:
            orders = []

            if 'symbol' in exec_params:
                symbols = [exec_params['symbol']] # convert to list
            else:
                symbols = exec_params['symbols']

            order_type = exec_params['type'].upper() if 'type' in exec_params else 'NONE'

            for symbol in symbols:
                symbol_orders = []
                exchange_symbol = self._symbol[symbol]

                try:
                    if order_type == 'OPEN':
                        symbol_orders = self._exchange.fetch_open_orders(exchange_symbol, params={'recvWindow': self._rec_window})
                    elif order_type == 'CLOSED':
                        symbol_orders = self._exchange.fetch_closed_orders(exchange_symbol, params={'recvWindow': self._rec_window})
                    else:
                        symbol_orders = self._exchange.fetch_orders(exchange_symbol, params={'recvWindow': self._rec_window})
                except:
                    time.sleep(self._exec_wait * 3)
                    try:
                        if order_type == 'OPEN':
                            symbol_orders = self._exchange.fetch_open_orders(exchange_symbol, params={'recvWindow': self._rec_window})
                        elif order_type == 'CLOSED':
                            symbol_orders = self._exchange.fetch_closed_orders(exchange_symbol, params={'recvWindow': self._rec_window})
                        else:
                            symbol_orders = self._exchange.fetch_orders(exchange_symbol, params={'recvWindow': self._rec_window})
                    except Exception as e:
                        print(e)
                
                if len(symbol_orders) > 0:
                    for order in symbol_orders:
                        self.__decorate_order(order)
                        orders.append(order)
            
            if orders is None:
                orders = []

            return orders

        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            print(exc_type)
            print(exc_obj)
            print(exc_tb)
            print(exc_tb.tb_lineno)
            raise InteroperationError('MARKET PROXY (CCXT-FTX) -> Get order list error: {}'.format(e))

    def modify_order(self, exec_params=None):
        return NotImplementedError

    def cancel_order(self, exec_params=None):
        try:
            exchange_symbol = self._symbol[exec_params['symbol']]
            self._exchange.cancel_order(exec_params['order_no'], symbol=exchange_symbol)
            return True
        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            print(exc_type)
            print(exc_obj)
            print(exc_tb)
            print(exc_tb.tb_lineno)
            raise InteroperationError('MARKET PROXY (CCXT-FTX) -> Cancel order error: {}'.format(e))

    def cancel_orders(self, exec_params=None):
        try:
            if 'order_nos' in exec_params and len(exec_params['order_nos']) > 0:
                for order_no in exec_params['order_nos']:
                    exchange_symbol = self._symbol[exec_params['symbol']]
                    self._exchange.cancel_order(order_no, symbol=exchange_symbol)
            else:
                raise Exception('Invalid orders_no')
        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            print(exc_type)
            print(exc_obj)
            print(exc_tb)
            print(exc_tb.tb_lineno)
            raise InteroperationError('MARKET PROXY (CCXT-FTX) -> Cancel multiple orders error: {}'.format(e))
    # =========================================================================================================
    # END: Fine-grained methods
    # =========================================================================================================

    # =========================================================================================================
    # BEGIN: Additional methods
    # =========================================================================================================
    def get_trades(self, exec_params=None):
        # Returns historical trades
        if 'since' not in exec_params:
            raise Exception('exec_params must contains since parameter')

        exchange_symbol = self._symbol[exec_params['symbol']]
        trades = self._exchange.fetch_my_trades(symbol=exchange_symbol, since=exec_params['since'])
        if trades is None:
            trades = []
        else:
            self.__decorate_trade(trades)
        return trades

    def get_candlestick(self, symbol, timeframe, limit=None):
        """Returns candlesticks of specified symbol and other parameters
        :param symbol: (string) symbol
        :param timeframe: (string) time frame, such as 1m, 5m, 15m, 30m, 60m, 1d,...
        :param limit: (int) max returned candles, MUST <= 1,000 candles, if None, will return 500 candles as default
        :return: list of lists, each list contains: Unix timestamp, open, high, low, close volume
        *NOTE: format of time is Unix timestamp (milliseconds)
        """
        candles = None
        try:
            exchange_symbol = self._symbol[symbol]

            if limit is not None:
                if limit > 1000:
                    raise Exception('Limit exceeded, cannot load over 1,000 candles')

                candles = self._exchange.fetch_ohlcv(exchange_symbol, timeframe, params={'limit': limit})
            else:
                candles = self._exchange.fetch_ohlcv(exchange_symbol, timeframe)
        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            print(exc_type)
            print(exc_obj)
            print(exc_tb)
            print(exc_tb.tb_lineno)
            raise InteroperationError('MARKET PROXY (CCXT-FTX) -> Get candlestick error: {}'.format(e))
        return candles

    def get_coin(self, balances, coin):
        coin_balance = 0.0
        if balances is not None and len(balances) > 0:
            for balance in balances:
                if balance['asset'] == coin:
                    coin_balance = balance['free']
                    break
        return coin_balance

    # PRIVATE METHODS =========================================================================
    def __get_valid_values(self, list_data, chk_field, check_sign=True):
        """
        The sign of some fields, such as 'positionAmt': + = long position, - = short position.
        """
        new_list = []
        for item in list_data:
            val = float(item[chk_field])
            if val > 0 or (check_sign == True and val != 0):
                new_list.append(item)
        return new_list

    def __decorate_position(self, positions):
        """
        Decorate position data by adjusting format to use system schema.
        The default implementation of this function is for FTX. In case of other exchange, this function should be overridden.
        param: symbol - (str) common symbol name to filter
        """
        position_list = []

        if positions is not None and len(positions) > 0:

            for pos in positions:
                # Add additional fields to original position data loaded from market.
                # Additional fields are trade_type, quantity, symbol_name, stop_loss, take_profit, robot_name, label.

                # NOTE: 'entry_time' is saved in position_entry_mem in BaseExecRobot in base_exec.py
                # The 'entry_time' is saved after opened new position immediately.

                positionAmt = float(pos['positionAmt'])

                if positionAmt != 0:
                    pos['quantity'] = abs(positionAmt)

                    if pos['positionSide'].upper() == 'LONG':
                        pos['trade_type'] = cons.BUY
                    elif pos['positionSide'].upper() == 'SHORT':
                        pos['trade_type'] = cons.SELL

                pos['entry_price'] = float(pos['entryPrice']) if 'entryPrice' in pos else 0.0
                pos['unrealized_profit'] = float(pos['unrealizedProfit']) if 'unrealizedProfit' in pos else 0.0

                pos['com_fee'] = 0.0
                if pos['entry_price'] > 0:
                    fee_rate = 0.0
                    if self._account_type.upper() == 'FUTURES':
                        fee_rate = float(self._fee_rate_futures)
                    elif self._account_type.upper() == 'SPOT':
                        fee_rate = float(self._fee_rate_futures)

                    pos['com_fee'] = self.__cal_fee(pos['entry_price'], pos['quantity'], fee_rate)
                
                pos['symbol_name'] = pos['symbol'].replace('/', '').replace('USDT', 'USD')
                pos['stop_loss'] = 0.0
                pos['take_profit'] = 0.0

                position_list.append(pos)

        return position_list

    def __decorate_trade(self, trades):
        """
        Decorate trade data by adjusting format to use system schema.
        param: symbol - (str) common symbol name to filter
        """
        if type(trades) is list:
            for trade in trades:
                trade['symbol_name'] = trade['symbol'].replace('/', '').replace('USDT', 'USD')
                trade['datetime'] = trade['datetime'].split('.')[0].replace('T', ' ')

    def __decorate_order(self, order, symbol):
        """
        Decorate trade data by adjusting format to use system schema.
        param: symbol - (str) common symbol name to filter
        """
        if 'info' in order:
            order['symbol_name'] = order['symbol'].replace('/', '').replace('USDT', 'USD')

            if order['type'].lower() == 'stop_market':
                order['type'] == 'stop_market'
            elif order['type'].lower() == 'take_profit_market':
                order['type'] == 'take_profit_market'

            if 'positionSide' in order['info'] and order['info']['positionSide'] is not None:
                if order['info']['positionSide'].upper() == 'LONG':
                    order['close_side'] = 'buy'
                elif order['info']['positionSide'].upper() == 'SHORT':
                    order['close_side'] = 'sell'

    def __cal_fee(self, price, pos_size, fee_rate):
        return price * pos_size * fee_rate

    # =========================================================================================================
    # END: Additional methods
    # =========================================================================================================
