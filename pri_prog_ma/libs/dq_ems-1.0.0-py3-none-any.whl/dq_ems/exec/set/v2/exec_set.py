import datetime, time
import sys
import pandas as pd

import datetime_util
import dq_ems.cons as cons

from dq_ems.base_ems import BaseExec
from dq_ems.error import ExecutionError


class ExecSetTFEX(BaseExec):
    """A simple execution.
    """

    def __init__(self, config, **kwargs):
        super().__init__(config, **kwargs)  

    # =========================================================================================================
    # BEGIN: Execute trading action methods
    # =========================================================================================================
    def _handle_open_trade(self, **wargs):
        position_side = None
        quantity = 0.0
        
        # exec_params = {
        #                 "symbol": signal_data["symbol"]
        #                 ,"price": signal_data["price"]
        #                 ,"volume": signal_data["position_size"]
        #                 ,"side": side
        #                 ,"position": position
        #                 ,"price_type": trade_type
        #             }


        try:
            market_proxy = kwargs["market_proxy"]
            new_order = kwargs["order"]
            print("000-222")
            #firstly, get all current position
            positions = market_proxy.get_positions()
            print("000-333")
            max_retry = 10

            trade_type = TradeTypeConverter.get_tradetype_stt(new_order["trade_type"] )
            print("000-444 position>>", positions)
            if positions:
                for position in positions:
                    print("Current Position############################>>>", position)
                    #check if new order is close position then use position size from position
                    if new_order["symbol"] == position["symbol"] and (new_order["side"] == Side.LONG_CLOSE.value or new_order["side"] == Side.SHORT_CLOSE.value):
                        #close the current position
                        side, order_position = SideConverter.get_side_position(new_order["side"])
                        position_size = position["available_long_position"] if position["has_long_position"] == True else position["available_short_position"]
                        exec_params = {
                            "symbol": new_order["symbol"]
                            ,"price": new_order["price"]
                            ,"volume": position_size
                            ,"side": side
                            ,"position": order_position
                            ,"price_type": trade_type
                        }
                        print("11111 Execution param for order:::::::::::::::::::::::::", exec_params)
                        trade = market_proxy.open_trade(exec_params=exec_params)

                    #find the diff. position with new position, if current is open long, current position must close by short close
                    elif new_order["symbol"] == position["symbol"] and new_order["side"] == Side.SHORT_OPEN.value and position["has_long_position"] == True:
                        #close the current position
                        side, order_position = SideConverter.get_side_position(Side.SHORT_CLOSE.value)
                        exec_params = {
                            "symbol": position["symbol"]
                            ,"price": new_order["price"]
                            ,"volume": position["available_long_position"]
                            ,"side": side
                            ,"position": order_position
                            ,"price_type": trade_type
                        }
                        print("22222 Execution param for order:::::::::::::::::::::::::", exec_params)
                        #try close the position
                        trade = market_proxy.open_trade(exec_params=exec_params)
                        retry = 0
                        while retry <= max_retry:
                            if trade is None or ("success" in trade and trade["success"] == False):
                                trade = market_proxy.open_trade(exec_params=exec_params)
                            else:
                                if "success" in trade and trade["success"] == True:
                                    order = market_proxy.get_order(exec_params=trade["data"])

                                    #not found current position that mean the position already closed
                                    if order and order["status"] == "M":
                                        break

                            time.sleep(1)
                            retry += 1

                    #find the diff. position with new position, if current is open long, current position must close by short close
                    elif new_order["symbol"] == position["symbol"] and new_order["side"] == Side.LONG_OPEN.value and position["has_short_position"] == True:
                        #close the current position
                        side, order_position = SideConverter.get_side_position(Side.LONG_CLOSE.value)
                        exec_params = {
                            "symbol": position["symbol"]
                            ,"price": new_order["price"]
                            ,"volume": position["available_short_position"]
                            ,"side": side
                            ,"position": order_position
                            ,"price_type": trade_type
                        }
                        print("33333 Execution param for order:::::::::::::::::::::::::", exec_params)
                        #try close the position
                        trade = market_proxy.open_trade(exec_params=exec_params)
                        retry = 0
                        while retry <= max_retry:
                            if trade is None or ("success" in trade and trade["success"] == False):
                                trade = market_proxy.open_trade(exec_params=exec_params)
                            else:
                                if "success" in trade and trade["success"] == True:
                                    order = market_proxy.get_order(exec_params=trade["data"])

                                    #not found current position that mean the position already closed
                                    if order and order["status"] == "M":
                                        break

                            time.sleep(1)
                            retry += 1

            #execute new order
            if new_order["side"] != Side.LONG_CLOSE.value and new_order["side"] != Side.SHORT_CLOSE.value:
                side, order_position = SideConverter.get_side_position(new_order["side"])
                exec_params = {
                    "symbol": new_order["symbol"]
                    ,"price": new_order["price"]
                    ,"volume": int(new_order["position_size"])
                    ,"side": side
                    ,"position": order_position
                    ,"price_type": trade_type
                }
                print("4444 Execution param for order:::::::::::::::::::::::::", exec_params)
                trade = market_proxy.open_trade(exec_params=exec_params)

            # Memorize entry position because it is difficult to get entry state of position in some broker/platform/exchange
            # Such as entry date time, entry price, etc.
            if exec_params['action'] == 'OPEN':
                self.position_entry_mem['open_time'] = datetime_util.utcnow().strftime('%Y-%m-%dT%H:%M:%S%Z')
                self.position_entry_mem['label'] = label
                self.position_entry_mem['symbol_name'] = symbol
                self.position_entry_mem['trade_type'] = exec_params['trade_type'].upper()
                self.position_entry_mem['quantity'] = quantity
                self.position_entry_mem['stop_loss'] = stop_loss
                self.position_entry_mem['take_profit'] = take_profit

                # Memorize entry position to database
                self.trade_mem_proxy.save_entry_pos(self.position_entry_mem)
            # NOTE: other fields are ignored
        
            msg = f'Open trade success\n{self.config["market"]}-{self.config["broker_id"]}\nacc no:{self.config["account_number"]}\nsymbol:{symbol}\ntrade_type:{position_side}\nquantity:{quantity}'
            self.notify_proxy.send_notify(msg, {'notify_token': self.admin_notify_token})
        except Exception as e:
            msg = f'Open new trade error\nexception:{e}'
            raise ExecutionError(msg)

    def _handle_close_trade(self, exec_params):
        position_side = None
        quantity = 0.0

        try:
            label = exec_params['label']
            symbol = exec_params['symbol_name']

            if exec_params['trade_type'].upper() == 'BUY':
                position_side = 'LONG'
                close_side = 'sell'
            else:
                position_side = 'SHORT'
                close_side = 'buy'

            # NOTE: MUST set type of quantity to float or int in trade model
            quantity = exec_params['quantity']

            # Send close order using market price
            self.market_proxy.close_trade(exec_params={'symbol': symbol, 'type': 'market'
                                                        , 'side': close_side, 'positionSide': position_side
                                                        , 'amount': quantity, 'clientOrderId': label})

            msg = f'Close trade success\n{self.config["market"]}-{self.config["broker_id"]}\nacc no:{self.config["account_number"]}\nsymbol:{symbol}\ntrade_type:{position_side}\nquantity:{quantity}'
            self.notify_proxy.send_notify(msg, {'notify_token': self.admin_notify_token})
        except Exception as e:
            msg = f'Close existing trade error\nexception:{e}'
            raise ExecutionError(msg)
        

    def _handle_send_stop_order(self, exec_params):
        position_side = None
        quantity = 0.0
        sl_price = 0.0
        tp_price = 0.0

        try:
            label = exec_params['label']
            symbol = exec_params['symbol_name']

            if exec_params['trade_type'] is None:
                raise Exception(f"Invalid exec_params value")

            if exec_params['trade_type'].upper() == 'BUY':
                position_side = 'LONG'
                close_side = 'sell'
            else:
                position_side = 'SHORT'
                close_side = 'buy'

            # NOTE: MUST set type of quantity to float or int in trade model
            quantity = exec_params['quantity']

            if 'stop_loss_price' in exec_params and exec_params['stop_loss_price'] != 0.0:
                sl_price = exec_params['stop_loss_price']
                self.market_proxy.open_trade(exec_params={'symbol': symbol
                                                            , 'side': close_side, 'positionSide': position_side
                                                            , 'stop_loss_price': sl_price
                                                            , 'amount': quantity, 'clientOrderId': f'{label}-SL'})

            if 'take_profit_price' in exec_params and exec_params['take_profit_price'] != 0.0:
                tp_price = exec_params['take_profit_price']
                self.market_proxy.open_trade(exec_params={'symbol': symbol
                                                            , 'side': close_side, 'positionSide': position_side
                                                            , 'take_profit_price': tp_price
                                                            , 'amount': quantity, 'clientOrderId': f'{label}-TP'})

            msg = f'Send stop order success\n{self.config["market"]}-{self.config["broker_id"]}\nacc no:{self.config["account_number"]}\nsymbol:{symbol}\ntrade_type:{position_side}\nquantity:{quantity}\nSL price:{sl_price}\nTP price:{tp_price}'
            self.notify_proxy.send_notify(msg, {'notify_token': self.admin_notify_token})
        except Exception as e:
            if exec_params['trade_type'] is None and self.cur_position['trade_type'] is None:
                pass
            else:
                exc_type, exc_obj, exc_tb = sys.exc_info()
                print(exc_type)
                print(exc_obj)
                print(exc_tb)
                print(exc_tb.tb_lineno)
                msg = f'Send stop order error\nSL price:{sl_price}\nTP price:{tp_price}\nexception:{e}'
                raise ExecutionError(msg)

    def _handle_cancel_trade(self, exec_params):
        if self.config['enable_send_sltp_order'] == True:
            open_orders = exec_params['orders']
            trade_type = exec_params['trade_type']

            # Get order no of SL order and TP order
            sl_order_no, tp_order_no = self._get_sltp_order_nos(open_orders, trade_type)

            # Cancel SL/TP orders
            if sl_order_no is not None:
                self.market_proxy.cancel_order(exec_params={'order_no': sl_order_no, 'symbol': self.symbol_name})
            if tp_order_no is not None:
                self.market_proxy.cancel_order(exec_params={'order_no': tp_order_no, 'symbol': self.symbol_name})
    # =========================================================================================================
    # END: Execute trading action methods
    # =========================================================================================================


    # =========================================================================================================
    # BEGIN: Helper methods
    # =========================================================================================================
    def _build_trade_input(self, symbol_name, timeframe, correl_id=None
                            , bar_num_require=1, interval_price_load_size=1
                            , require_orders=False, require_trades=False):
        """Build trade input to be sent to trade model for bar execution
        """
        # Load account data from market, including order, trades, positions
        self.account_data = self.market_proxy.get_account_data(exec_params={'symbol': symbol_name
                                                                            , 'require_orders': require_orders
                                                                            , 'require_trades': require_trades})
        """
        bar_num = self.symbol_config['bar_num_require']

        # Get candlesticks (dataframe) from database
        if self.cache['dataset'] is None:
            df_price_data = self.data_feed_proxy.get_candles(symbol_name
                                                              , timeframe
                                                              , bar_num)
            self.cache['dataset'] = df_price_data
        else:
            # Load latest candles and append to existing candles for predict signal
            df_new_prices = self.data_feed_proxy.get_candles(symbol_name
                                                                , timeframe
                                                                , interval_price_load_size)
            self._add_rows(df_new_prices, bar_num, 'DATETIME')
        """
        # Build trade input
        trade_input = {}
        trade_input['correl_id'] = correl_id
        #trade_input['dataset'] = self.cache['dataset']
        trade_input['account'] = self.account_data['account_info']
        trade_input['position'] = self.account_data['position'] # 1 position / 1 bot
        trade_input['orders'] = self.account_data['orders']
        #trade_input['trades'] = self.account_data['trades']

        return trade_input

    def _is_trade_time(self):
        """This method must be implemented by subclass
        """
        raise NotImplementedError

    def _decorate_exec_params(self, exec_params, position=None, trade_action=None):
        """Change or add fields in exec_params to match the target trading platform.
        :param exec_params: (dict) parameters for trade execution
        :param position: (dict)
        :param trade_action: (dict)
        """
        pass

    def _map_cur_pos(self, position, is_blank=True, **kwargs):
        self.cur_position['label'] = position['label']
        self.cur_position['robot_name'] = position['robot_name']
        self.cur_position['symbol_name'] = position['symbol_name']

        if is_blank == False:
            if 'quantity' in position:
                quantity = position['quantity']
            else:
                quantity = kwargs['quantity'] if kwargs is not None and 'quantity' in kwargs else 0.0
            self.cur_position['trade_type'] = position['trade_type']
            self.cur_position['quantity'] = quantity
            self.cur_position['stop_loss'] = position['stop_loss']
            self.cur_position['take_profit'] = position['take_profit']
        else:
            self.cur_position['trade_type'] = 'IDLE'
            self.cur_position['quantity'] = 0.0
            self.cur_position['stop_loss'] = 0.0
            self.cur_position['take_profit'] = 0.0

    def _has_sltp_orders(self, orders):
        # Default is False
        # This method should be overridden by subclass
        return False

    def _get_position(self, positions):
        position = None
        if type(positions) is list and len(positions) > 0:
            for pos in positions:
                if pos['symbol_name'] == self.symbol_name:
                    position = pos
                    break
        return position

    def _cal_pos_size(self, cal_pos_size_formula, trade_input, **kwargs):
        pos_size = 0.0

        if cal_pos_size_formula == 1:
            print('Hello')
        elif cal_pos_size_formula == 2:
            print('Hi')
        elif cal_pos_size_formula == 3:
            print('Welcome')

        return pos_size

    def get_symbol_id_index(self):
        symbol_id_index_dict = {}
        for i in range(0, len(self.config['symbols'])):
            symbol_id = self.config['symbols'][i]['id']
            symbol_id_index_dict[str(symbol_id)] = i
        return symbol_id_index_dict
    # =========================================================================================================
    # END: Helper methods
    # =========================================================================================================
