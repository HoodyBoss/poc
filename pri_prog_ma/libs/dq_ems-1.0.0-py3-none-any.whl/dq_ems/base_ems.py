import datetime, pytz, time
import sys
import pandas as pd

import dq_ems.cons as cons


class BaseStrategyEndpointProxy():
    """A base class of trading strategy (or trading model) endpoint proxy.
    You can create subclass to control logic for the calling to your trading strategy in a variety of implementations.
    """
    def execute(self, trade_input, **kwargs):
        exec_output = {}
        return exec_output


class BaseTradeMemoryProxy():
    def __init__(self, config=None):
        self.config = config

    def prepare(self, robot_labels=None, robot_symbol_infos=None, **kwargs):
        pass

    def load_trade_pos(self, **kwargs):
        positions = []
        return positions

    def save_trade_pos(self, trade_positions, **kwargs):
        result = False
        return result

    def load_entry_pos(self, **kwargs):
        positions = []
        return positions

    def save_entry_pos(self, trade_positions, **kwargs):
        result = False
        return result

    def save_closed_trades(self, closed_trades):
        result = False
        return result


class BaseDataFeedProxy():
    def __init__(self, **kwargs):
        pass

    def get_candles(self, symbol_name, timeframe, limit_candles=1000, **kwargs):
        return None


class BaseNotifyProxy():
    def send_notify(self, msg, params):
        pass


# =============================================================================================================
# BEGIN: Base class of trade account loader
# =============================================================================================================
class BaseTradeAccountLoader:
    """
    Summary:
        A super class of trade account loader.
    """

    def load(self, trade_account_id, params=None):
        """
        Summary:
            Returns trade account dictionary object.

        Parameters:
            trade_account_id (str): an unique id of trade account to be used as key for loading
            params (dict): an optional parameters depends on implementation of each child class

        Returns:
            dict: a trade account
        """
        raise NotImplementedError

# =============================================================================================================
# END: Base class of trade account loader
# =============================================================================================================

# =============================================================================================================
# BEGIN: Base class of market/broker/exchange session cache
# =============================================================================================================
class BaseMarketSessionCache:

    """
    Summary:
        A super class market session cache for storing and retrieving market session.
        Market session type is dictionary.
        Schema is:
        {
            'session_key': <str>
            , 'session_val': <object>
            , 'last_run_ts': <datetime>
        }
        session_key is an unique session key
        session_val is a session object that the exact type depends on market/broker/exchange platform
        last_run_ts is a last datetime of creating new connection, format is Unix timestamp, for example: 1613012700

        *last_run_ts is optional, default value is 0
    """

    def set(self, session_key, session_val, last_run_ts=0):
        """
        Summary:
            Store market session dictionary.

        Parameters:
            session_key (str): an unique session key
            session_val (object): a session object that the exact type depends on market/broker/exchange platform
            last_run_ts (int): datetime, format is Unix timestamp, for example: 1613012700
        """
        raise NotImplementedError

    def get(self, session_key):
        """
        Summary:
            Returns market session dictionary
        
        Parameters:
            session_key (str): an unique session key
        
        Returns:
            dict: a session dictionary comprises 'session_key', 'session_val', 'last_run_ts'
        """
        raise NotImplementedError
# =============================================================================================================
# END: Base class of market/broker/exchange session cache
# =============================================================================================================


# =============================================================================================================
# BEGIN: Base class of market/broker/exchange connector
# =============================================================================================================
class BaseMarketConnector:
    """
    Summary:
        A super class of market connector that is responsible for connect to market/broker/exchange.
    """

    def connect(self, trade_account, mkt_session_cache, check_timeout=0, params=None):
        """
        Summary:
            Returns all current positions by loading from market/broker/exchange.
            Market connection preparation process:
            1. Load session from cache
            - If session is None:
            a) Connect market/broker/exchange and receive new session
            b) Get timestamp
            c) Store new session and timestamp into cache
            - If session is not None:
            a) check status (valid or active or alive ?)
            b) if status is not valid (expired) then create new connection > get timestamp > store into cache
            2. Return session

            Market session status is 'ok' or None

        Parameters:
            trade_account (dict): a dictionary object comprises required fields for authentication, authorization
                                    and trading (e.g. send order, load account data).
                                    Example fields: API key, API secret, account no., account type
                                    These required fields depend on market/broker/exchange that this market proxy object
                                    will interoperating to.
            mkt_session_cache (object):  a market session cache object
            check_timeout (int): interval period in seconds to check timeout
            params (dict): an optional parameters
        """
        mkt_session = None

        try:
            now_ts = self.__get_timestamp()
            session_key = trade_account['id']
            print("Base connector >>> mkt_session_cache ::", mkt_session_cache)
            # Get market session from cache and get status
            mkt_session_dict = mkt_session_cache.get(session_key)
            mkt_session = None
            if mkt_session_dict is not None:
                mkt_session = mkt_session_dict['session_val']

            mkt_session_status = self._get_mkt_session_status(mkt_session)
            print("mkt_session1 >>> ", mkt_session)
            mkt_session = None
            print("mkt_session2 >>> ", mkt_session)
            print("mkt_session_status >>> ", mkt_session_status)
            # Evaluate market session
            if mkt_session is None \
                or (type(mkt_session_status) is str and mkt_session_status.lower() != 'ok') \
                or (mkt_session is not None and now_ts - mkt_session_dict['last_run_ts'] > check_timeout):

                # Create new market session and save to cache
                mkt_session = self._create_mkt_session(trade_account, check_timeout, params)
                mkt_session_cache.set(session_key, mkt_session, last_run_ts=now_ts)

            if mkt_session is None:
                raise Exception('Process completed but market session is None')

        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            raise Exception(f'Connect market error: {e}, line no. {exc_tb.tb_lineno}')

        return mkt_session

    def _get_mkt_session_status(self, mkt_session, params=None):
        """
        Summary:
            Returns status of market session. This method must be implemented by child class.
            Default OK status of mk_session_status is 'ok'

        Parameters:
            mkt_session (object): a session object that the exact type depends on market/broker/exchange platform
            params (dict): an optional parameters

        Returns:
            str: a status of market session
        """
        raise NotImplementedError

    def _create_mkt_session(self, trade_account, check_timeout, params=None):
        """
        Summary:
            Create market session by connecting to market/broker/exchange. This method must be implemented by child class.

        Parameters:
            trade_account (dict): a dictionary object comprises required fields for authentication, authorization
                                    and trading (e.g. send order, load account data).
                                    Example fields: API key, API secret, account no., account type
                                    These required fields depend on market/broker/exchange that this market proxy object
                                    will interoperating to.
            check_timeout (int): interval period in seconds to check timeout
            params (dict): an optional parameters

        Returns:
            object: a market session object, type depends market/broker/exchange platform
        """
        raise NotImplementedError

    def __get_timestamp(self):
        return datetime.datetime.now().astimezone( pytz.timezone('UTC') ).timestamp()

# =============================================================================================================
# END: Base class of market/broker/exchange connector
# =============================================================================================================

# =============================================================================================================
# BEGIN: Base class of market proxy
# =============================================================================================================
class BaseMarketProxy():
    """
    Summary:
        A super class of market proxy that is responsible for interoperating to market/broker/exchange platform.
    """

    def __init__(self, trade_account):
        """
        Summary:
            Prepare market proxy for specified trading account.

        Parameters:
            trade_account (dict): a dictionary object comprises required fields for authentication, authorization
                                    and trading (e.g. send order, load account data).
                                    Example fields: API key, API secret, account no., account type
                                    These required fields depend on market/broker/exchange that this market proxy object
                                    will interoperating to.
        """
        self._trade_account = trade_account

    def prepare(self, exec_params=None):
        """
        Summary:
            Prepare market proxy after completed initialization. This is an optional operation depends on child class designing.
        
        Parameters:
            exec_params (dict): a dictionary object of specific data
        """
        pass

    # =========================================================================================================
    # BEGIN: Coarse-grained methods
    # =========================================================================================================
    def get_positions(self, exec_params=None):
        """
        Summary:
            Loads all current positions of all symbols from market/broker/exchange.

        Parameters:
            exec_params (dict): an execution parameters

        Returns:
            list: list of dictionaries of positions
        """
        raise NotImplementedError

    def get_account_data(self, require_orders=False, require_trades=False, exec_params=None):
        """
        Summary:
            Loads account data from market/broker/exchange.
            Default account data comprises of account info and positions.
            Optional account data are active orders (e.g. pending, queuing), trades (transaction or matched orders).

        Parameters:
            exec_params (dict): an execution parameters

        Returns:
            dict: an account data comprices account info, positions,...
        """
        raise NotImplementedError

    # =========================================================================================================
    # END: Coarse-grained methods
    # =========================================================================================================

    # =========================================================================================================
    # BEGIN: Fine-grained methods
    # =========================================================================================================
    def open_trade(self, exec_params=None):
        """
        Summary:
            Open new trade for specified execution parameters
        
        Parameters:
            exec_params (dict): an execution parameters
        """
        raise NotImplementedError

    def close_trade(self, exec_params=None):
        """
        Summary:
            Close (partially or fully) existing trade for specified execution parameters
        
        Parameters:
            exec_params (dict): an execution parameters
        """
        raise NotImplementedError

    def get_account_info(self, exec_params=None):
        """
        Summary:
            Loads account info for specified execution parameters

        Parameters:
            exec_params (dict): an execution parameters

        Returns:
            dict: an account info, e.g. balance, equity,...
        """
        raise NotImplementedError

    def get_portfolio(self, exec_params=None):
        """
        Summary:
            Loads portfolio (all current positions) for specified execution parameters
        
        Parameters:
            exec_params (dict): an execution parameters

        Returns:
            dict: a portfolio data, usually a list of positions
        """
        raise NotImplementedError

    def get_order(self, exec_params=None):
        """
        Summary:
            Loads one order for specified execution parameters
        
        Parameters:
            exec_params (dict): an execution parameters

        Returns:
            dict: an order
        """
        raise NotImplementedError

    def get_orders(self, exec_params=None):
        """
        Summary:
            Loads all orders or many orders for specified execution parameters
        
        Parameters:
            exec_params (dict): an execution parameters

        Returns:
            list: list of dictionaries of order
        """
        raise NotImplementedError

    def modify_order(self, exec_params=None):
        """
        Summary:
            Modify existing pending or  queueing order for specified execution parameters
        
        Parameters:
            exec_params (dict): an execution parameters
        """
        raise NotImplementedError

    def cancel_order(self, exec_params=None):
        """
        Summary:
            Cancel order for specified execution parameters
        
        Parameters:
            exec_params (dict): an execution parameters
        """
        raise NotImplementedError

    def cancel_orders(self, exec_params=None):
        """
        Summary:
            Cancel many orders for specified execution parameters
        
        Parameters:
            exec_params (dict): an execution parameters
        """
        raise NotImplementedError

    def cal_fee(self, price, pos_size, fee_rate, exec_params=None):
        """
        Summary:
            Calculate commission fee
        
        Parameters:
            price (float): product price
            pos_size (float): a position size or trade unit or trade quantity
            fee_rate (float): a fee rate using by market/broker/exchange
            exec_params (dict): an execution parameters

        Returns:
            float: a calculated fee
        """
        raise NotImplementedError
    # =========================================================================================================
    # END: Fine-grained methods
    # =========================================================================================================
# =============================================================================================================
# END: Base class of market proxy
# =============================================================================================================


# =============================================================================================================
# BEGIN: Base class of execution robot
# =============================================================================================================
class BaseExec():
    """
    Summary:
        A super class of execution. Most operations perform simple execution management.
    """

    def __init__(self, config, **kwargs):
        self.config = config

        # Binding proxy objects
        self.notify_proxy = kwargs['notify_proxy']
        self.market_proxy = kwargs['market_proxy']

        self.admin_notify_token = config['admin_notify_token']

        #self.last_run_ts = 0  # datetime, format is Unix timestamp, for example: 1613012700
        self.day_millis = 24 * 60 * 60 * 1000
        self.holidays = []
        self.holidays_last_load_day = 0

        self.timeframe = '' # must be initialized by subclass

        # robot_labels is dictionary, key is robot name, value is label (same as magic number in MT4)
        # robot label is used to identify position or trade or order of each trading robot
        # The identity of trading robot is label.
        # robot_symbol_infos is dictionary, key is robot name, value is dictionary of symbol config
        #self.robot_labels, self.robot_symbol_infos = self.build_labels_and_symbol_infos()
        # symbol_tr_robot_conf is dictionary, key is symbol, value is trading robot config dict
        # Do not forget that 1 trading robot / 1 symbol
        #self.symbol_tr_robot_conf = self.get_symbol_robot_conf()

    # =========================================================================================================
    # BEGIN: Execute trading action methods
    # =========================================================================================================
    def _handle_open_trade(self, exec_params):
        """
        Summary:
            Handle open new trade for specified execution parameters
            Format of exec_params (at least fields) ->
            {
                symbol:<str>
                , trade_type:<int>
                , quantity:<float>
            }
            *trade_type -> 1=buy or long, 2=sell or short, 3=idle
        """
        raise NotImplementedError

    def _handle_close_trade(self, exec_params):
        """
        Summary:
            Handle close (partially or fully) existing trade for specified execution parameters
            Format of exec_params (at least fields) ->
            {
                symbol:<str>
                , trade_type:<int>
                , quantity:<float>
            }
            *trade_type -> 1=buy or long, 2=sell or short, 3=idle
        """
        raise NotImplementedError

    def _handle_send_stop_order(self, exec_params):
        """
        Summary:
            Handle send stop (or SL/TP) order(s) for specified execution parameters
        
            NOTE: This method is optional. It depends on your execution strategy.
            Because of some execution strategies monitors tick data and check SL/TP and then perform close trade immediately.
        """
        pass

    def _handle_cancel_trade(self, exec_params):
        """
        Summary:
            Handle cancel existing order(s) for specified execution parameters
        
            NOTE: This method is optional. It depends on your execution strategy.
            Because of some execution strategies has no open/queueing/pending order(s).
        """
        pass
    # =========================================================================================================
    # END: Execute trading action methods
    # =========================================================================================================


    # =========================================================================================================
    # BEGIN: Main execution method
    # =========================================================================================================
    def _execute_trade_action(self, trade_action):
        exec_error = None

        if self.config['enable_check_trade_time'] == True and self._is_trade_time() == False:
            raise Exception('Market close')

        try:
            action_code = trade_action['action_code']
            symbol_name = trade_action['symbol_name']
            trade_input = self._build_trade_input(symbol_name, self.timeframe, correl_id=None
                                                    , bar_num_require=1, interval_price_load_size=1
                                                    , require_orders=False, require_trades=False)
            position = trade_input['position']

            if action_code in [cons.ACTION_OPEN_BUY, cons.ACTION_OPEN_SELL, cons.ACTION_CLOSE_BUY, cons.ACTION_CLOSE_SELL \
                                , cons.ACTION_SCALE_OUT_BUY, cons.ACTION_SCALE_OUT_SELL, cons.ACTION_SCALE_IN_BUY, cons.ACTION_SCALE_IN_SELL]:
                action_name = 'Cancel order'

                # Cancel order(s) NOTE: This is an optional. Depends on execution strategy in child class.
                exec_params = {'label': trade_action['label']
                                , 'symbol_name': position['symbol_name']
                                , 'trade_type': position['trade_type']
                                , 'orders': trade_input['orders']
                                , 'trade_action': trade_action}
                self._decorate_exec_params(exec_params, position, trade_action)
                self._handle_cancel_trade(exec_params)

            # ===================================================================================================================

            if action_code in [cons.ACTION_OPEN_BUY, cons.ACTION_OPEN_SELL]:
                action_name = 'Open position'

                # 1) Close existing position
                if position is not None and position['quantity'] > 0:
                    position_quantity = self._cal_pos_size(trade_action['cal_pos_size_formula'], trade_input, master_bot_quantity=position['quantity'])
                    # Close trade
                    exec_params = {'action': 'CLOSE'
                                    , 'label': trade_action['label']
                                    , 'symbol_name': position['symbol_name']
                                    , 'trade_type': position['trade_type']
                                    , 'quantity': position_quantity}
                    self._decorate_exec_params(exec_params, position, trade_action)
                    self._handle_close_trade(exec_params)

                    time.sleep(self.config['wait_order_exec_seconds'])

                """You should do something to ensure the existing position has been closed success"""

                # 2) Open position
                action_quantity = self._cal_pos_size(trade_action['cal_pos_size_formula'], trade_input, master_bot_quantity=trade_action['quantity'])
                exec_params = {'action': 'OPEN'
                                , 'label': self.robot_label
                                , 'symbol_name': trade_action['symbol_name']
                                , 'trade_type': trade_action['trade_type']
                                , 'quantity': action_quantity
                                , 'stop_loss': trade_action['stop_loss']
                                , 'take_profit': trade_action['take_profit']}
                self._decorate_exec_params(exec_params, position, trade_action)
                self._handle_open_trade(exec_params)

            # =============================================================================================
            elif action_code in [cons.ACTION_CLOSE_BUY, cons.ACTION_CLOSE_SELL]:
                action_name = 'Close position'

                # Close existing position
                if position is not None and position['quantity'] > 0:
                    action_quantity = self._cal_pos_size(trade_action['cal_pos_size_formula'], trade_input, master_bot_quantity=trade_action['quantity'])
                    exec_params = {'action': 'CLOSE'
                                    , 'label': trade_action['label']
                                    , 'symbol_name': trade_action['symbol_name']
                                    , 'trade_type': trade_action['trade_type']
                                    , 'quantity': action_quantity}
                    self._decorate_exec_params(exec_params, position, trade_action)
                    self._handle_close_trade(exec_params)

            # =============================================================================================
            elif action_code in [cons.ACTION_SCALE_OUT_BUY, cons.ACTION_SCALE_OUT_SELL]:
                action_name = 'Scale out position'

                # Scale out position
                if position is not None and position['quantity'] > 0:
                    action_quantity = self._cal_pos_size(trade_action['cal_pos_size_formula'], trade_input, master_bot_quantity=trade_action['quantity'])
                    exec_params = {'action': 'SCALE_OUT'
                                    , 'label': trade_action['label']
                                    , 'symbol_name': trade_action['symbol_name']
                                    , 'trade_type': trade_action['trade_type']
                                    , 'quantity': action_quantity
                                    , 'stop_loss': trade_action['stop_loss']
                                    , 'take_profit': trade_action['take_profit']}
                    self._decorate_exec_params(exec_params, position, trade_action)
                    self._handle_close_trade(exec_params)

            # =============================================================================================
            elif action_code in [cons.ACTION_SCALE_IN_BUY, cons.ACTION_SCALE_IN_SELL]:
                action_name = 'Scale in position'

                # Open position
                if position is not None and position['quantity'] > 0:
                    action_quantity = self._cal_pos_size(trade_action['cal_pos_size_formula'], trade_input, master_bot_quantity=trade_action['quantity'])
                    exec_params = {'action': 'SCALE_IN'
                                    , 'label': trade_action['label']
                                    , 'symbol_name': trade_action['symbol_name']
                                    , 'trade_type': trade_action['trade_type']
                                    , 'quantity': action_quantity
                                    , 'stop_loss': trade_action['stop_loss']
                                    , 'take_profit': trade_action['take_profit']}
                    self._decorate_exec_params(exec_params, position, trade_action)
                    self._handle_open_trade(exec_params)
                                
            # ===================================================================================================================
            if self.config['enable_send_sltp_order'] == True:
                if action_code in [cons.ACTION_OPEN_BUY, cons.ACTION_OPEN_SELL, cons.ACTION_SCALE_OUT_BUY, cons.ACTION_SCALE_OUT_SELL \
                                    , cons.ACTION_SCALE_IN_BUY, cons.ACTION_SCALE_IN_SELL]:
                    action_name = 'Send stop order'
                                
                    time.sleep(self.config['wait_order_exec_seconds'])

                    action_quantity = self._cal_pos_size(trade_action['cal_pos_size_formula'], trade_input, master_bot_quantity=trade_action['quantity'])
                    exec_params = {'label': trade_action['label']
                                    , 'symbol_name': trade_action['symbol_name']
                                    , 'trade_type': trade_action['trade_type']
                                    , 'quantity': action_quantity
                                    , 'trade_action': trade_action}
                    exec_params['stop_loss_price'] = trade_action['stop_loss'] if trade_action['stop_loss'] != 0.0 else 0.0
                    exec_params['take_profit_price'] = trade_action['take_profit'] if trade_action['take_profit'] != 0.0 else 0.0

                    self._decorate_exec_params(exec_params, position, trade_action)
                    self._handle_send_stop_order(exec_params)

            # ===================================================================================================================
            # Resend SLTP orders when has active position but SLTP orders in broker/exchange has lost
            if action_code not in [cons.ACTION_OPEN_BUY, cons.ACTION_OPEN_SELL, cons.ACTION_CLOSE_BUY, cons.ACTION_CLOSE_BUY_WAIT
                                    , cons.ACTION_CLOSE_SELL, cons.ACTION_CLOSE_SELL_WAIT, cons.ACTION_WAIT]:
                
                has_sltp_orders = self._has_sltp_orders(trade_input['orders'])
                if has_sltp_orders == False:
                    action_name = 'Send stop order'

                    position_quantity = self._cal_pos_size(trade_action['cal_pos_size_formula'], trade_input, master_bot_quantity=position['quantity'])
                    exec_params = {'label': trade_action['label']
                        , 'symbol_name': trade_action['symbol_name']
                        , 'trade_type': position['trade_type']
                        , 'quantity': position_quantity
                        , 'trade_action': trade_action}
                    exec_params['stop_loss_price'] = position['stop_loss']
                    exec_params['take_profit_price'] = position['take_profit']
                    self._decorate_exec_params(exec_params, position, trade_action)
                    self._handle_send_stop_order(exec_params)

        except  Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            print(exc_type)
            print(exc_obj)
            print(exc_tb)
            print(exc_tb.tb_lineno)
            exec_error = {}
            exec_error['action'] = action_name
            exec_error['label'] = trade_action['label']
            exec_error['symbol_name'] = trade_action['symbol_name']
            exec_error['trade_type'] = trade_action['trade_type'] if 'trade_type' in trade_action.keys() else None
            exec_error['quantity'] = trade_action['quantity'] if 'quantity' in trade_action.keys() else None
            exec_error['exception'] = str(e)

            msg = 'EMS -> Execution error\nmarket: {}, account_no: {}:\n{}'.format(
                self.config["market"], self.config["account_number"], e)
            self.notify_proxy.send_notify(msg, {'notify_token': self.admin_notify_token})
        
        return exec_error
    # =========================================================================================================
    # END: Main execution method
    # =========================================================================================================


    # =========================================================================================================
    # BEGIN: Helper methods
    # =========================================================================================================
    def _build_trade_input(self, symbol_name, timeframe, correl_id=None
                            , bar_num_require=1, interval_price_load_size=1
                            , require_orders=False, require_trades=False):
        """
        Summary:
            Build trade input to be used by trade model. Can use any format

        Parameters:
            symbol_name (str):
            timeframe (str):
            correl_id (str):
            bar_num_require (int):
            interval_price_load_size (int):
            require_orders (bool):
            require_trades (bool):

        Returns:
            dict: a trade input data required by trading model or trading strategy
        """
        raise NotImplementedError

    def _is_trade_time(self):
        """
        Summary:
            This method must be implemented by subclass
        """
        raise NotImplementedError

    def _decorate_exec_params(self, exec_params, position=None, trade_action=None):
        """
        Summary:
            Change or add fields in exec_params to match the target trading platform.

        Parameters:
            exec_params (dict): parameters for trade execution
            position (dict):
            trade_action (dict):
        """
        pass

    def _map_cur_pos(self, position, is_blank=True, **kwargs):
        self.cur_position['label'] = position['label']
        self.cur_position['robot_name'] = position['robot_name']
        self.cur_position['symbol_name'] = position['symbol_name']

        if is_blank == False:
            if 'quantity' in position:
                quantity = position['quantity']
            else:
                quantity = kwargs['quantity'] if kwargs is not None and 'quantity' in kwargs else 0.0
            self.cur_position['trade_type'] = position['trade_type']
            self.cur_position['quantity'] = quantity
            self.cur_position['stop_loss'] = position['stop_loss']
            self.cur_position['take_profit'] = position['take_profit']
        else:
            self.cur_position['trade_type'] = 'IDLE'
            self.cur_position['quantity'] = 0.0
            self.cur_position['stop_loss'] = 0.0
            self.cur_position['take_profit'] = 0.0

    def _has_sltp_orders(self, orders):
        # Default is False
        # This method should be overridden by subclass
        return False

    def _get_position(self, positions):
        position = None
        if type(positions) is list and len(positions) > 0:
            for pos in positions:
                if pos['symbol_name'] == self.symbol_name:
                    position = pos
                    break
        return position

    def _cal_pos_size(self, cal_pos_size_formula, trade_input, **kwargs):
        raise NotImplementedError

    def get_symbol_id_index(self):
        symbol_id_index_dict = {}
        for i in range(0, len(self.config['symbols'])):
            symbol_id = self.config['symbols'][i]['id']
            symbol_id_index_dict[str(symbol_id)] = i
        return symbol_id_index_dict

    def build_labels_and_symbol_infos(self):
        robot_labels = {}
        robot_symbol_infos = {}
        symbol_id_index_dict = self.get_symbol_id_index()
        for tr_bot_conf in self.config['trading_robots']:
            robot_name = tr_bot_conf['name']
            robot_labels[robot_name] = tr_bot_conf['label']
            symbol_index = int(symbol_id_index_dict[str(tr_bot_conf['symbol'])])
            robot_symbol_infos[robot_name] = self.config['symbols'][symbol_index]
        return robot_labels, robot_symbol_infos

    def get_symbol_robot_conf(self):
        conf = {} # key is symbol name, value is trading robot config dict

        for tr_bot_conf in self.config['trading_robots']:
            trade_symbol_id = tr_bot_conf['symbol']

            found = False
            i = 0
            while found == False and i < len(self.config['symbols']):
                symbol_conf = self.config['symbols'][i]
                if symbol_conf['id'] == trade_symbol_id:
                    conf[symbol_conf['name']] = tr_bot_conf
                    found = True
                i = i + 1

            if found == True:
                break # exit for loop
        return conf
    # =========================================================================================================
    # END: Helper methods
    # =========================================================================================================
# =============================================================================================================
# END: Base class of execution robot
# =============================================================================================================
