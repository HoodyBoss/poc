import yaml


###
### Goal: Read config file,
###
class ConfigManager:

    config = None

    def __init__(self):
        pass

    def load_config(self):
        self.config = yaml.safe_load(open('config.yaml'))
        return self.config
