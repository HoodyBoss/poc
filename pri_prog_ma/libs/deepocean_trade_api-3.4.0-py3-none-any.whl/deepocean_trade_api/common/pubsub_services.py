import json
import os
import sys

import requests

# initial logging
from deepocean_trade_api.common import DOLogger
from deepocean_trade_api.common.config import ConfigManager

_config = ConfigManager()
_config = _config.load_config()
mode = _config["mode"]
log_name = "DEEPOCEAN_COMMON_PUBSUB_SERVICES"
logger = DOLogger(_env=mode, log_name=log_name, level=_config["logs"]["level"])
# live=production run on gcp otherwise, run on localhost


GCLOUD_PROJECT = os.getenv("CLOUD_PROJECT_ID")
BUCKET_NAME = os.getenv("BUCKET_NAME")
LINE_NOTI_ENDPOINT = os.getenv("LINE_NOTI_ENDPOINT")
BACKEND_API_GATEWAY_ENDPOINT = os.getenv("BACKEND_API_GATEWAY_ENDPOINT")
BACKEND_API_GATEWAY_APIKEY = os.getenv("BACKEND_API_GATEWAY_APIKEY")
NOTIFICATION_PUBSUB_TOPIC = os.getenv("NOTIFICATION_PUBSUB_TOPIC")


class PubSubServices:
    def local_broadcast_signal(self, signal_data):
        url = _config["local_subscriber_endpoint"]
        result_data = {}
        result_data.update({"system_status": signal_data["system_status"]})
        result_data.update({"exe": signal_data["exe"]})
        result_data.update({"signal_data": signal_data["grid_data"]})
        f = open('mocks/grid_subscriber_data.json')
        docs = json.load(f)
        for doc in docs:
            data = doc
            key = list(data.keys())[0]
            json_data = {}
            datas = {
                "userId": data[key]["user_id"],
                "strategyId": data[key]["strategy_id"],
                "apiKey": data[key]["apiKey"],
                "exchange": data[key]["exchange"],
                "testNet": data[key]["testNet"],
                "accountName": data[key]["sub_account_name"],
                "subAccountFlag": data[key]["subAccountFlag"],
                "line_token": data[key]["line_token"],
                "admin_line_token": signal_data["admin_line_token"],
                "bot_status": data[key]["system_status"],
            }  # data.get("admin_Line_token"),
            result_data.update({"subscribe_info": datas})
            # async_request.append(requests.get( url ))
            json_data.update({"message": {"data": {"data": {"message": result_data}}}})
            # async_request.append( post_signal( json_data ) )
            requests.post(url, json=json_data)

    # push pubsub
    def push_notificatoin_pubsub(self, json_data):
        # Instantiates a Pub/Sub client
        from google.cloud import pubsub_v1

        publisher = pubsub_v1.PublisherClient()
        topic_path = publisher.topic_path(GCLOUD_PROJECT, NOTIFICATION_PUBSUB_TOPIC)
        message_json = json.dumps(
            {
                'data': {'message': json_data},
            }
        )

        message_bytes = message_json.encode('utf-8')
        # Publishes a message
        try:
            publish_future = publisher.publish(topic_path, data=message_bytes)
            publish_future.result()  # Verify the publish succeeded
            return 'Message published.'
        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            logger.error(f'GCP utilities. Error: {e}, Line no.:{exc_tb.tb_lineno}')
            raise Exception(e)

    # common function to push pubsub
    def push_any_pubsub(self, project_id, pubsub_topic, json_data):
        # Instantiates a Pub/Sub client
        from google.cloud import pubsub_v1

        publisher = pubsub_v1.PublisherClient()
        topic_path = publisher.topic_path(project_id, pubsub_topic)
        message_json = json.dumps(
            {
                'data': {'message': json_data},
            }
        )
        message_bytes = message_json.encode('utf-8')
        # Publishes a message
        try:
            publish_future = publisher.publish(topic_path, data=message_bytes)
            publish_future.result()  # Verify the publish succeeded
            return 'Message published.'
        except Exception as e:
            return (e, 500)
