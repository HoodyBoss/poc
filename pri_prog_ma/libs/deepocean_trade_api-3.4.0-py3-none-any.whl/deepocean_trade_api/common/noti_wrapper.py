import json

import requests
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import Mail
from twilio.rest import Client

# log_name = "NOTI_WRAPPER_CLASS"

# # # Create a handler for Google Cloud Logging.
# gcloud_logging_client = google.cloud.logging.Client()
# gcloud_logging_handler = CloudLoggingHandler(gcloud_logging_client, name=log_name)

# # Create a stream handler to log messages to the console.
# stream_handler = logging.StreamHandler()
# stream_handler.setLevel(logging.INFO)

# # Now create a //logger and add the handlers:
# //logger = logging.get//logger(log_name)
# //logger.setLevel(logging.INFO)
# //logger.addHandler(gcloud_logging_handler)
# //logger.addHandler(stream_handler)

##########
### Email : sendgrid.com
### SMS : Twilio


class NotificationWrapper:

    line_endpoint = "https://notify-api.line.me/api/notify"
    telegram_endpoint = 'https://api.telegram.org/bot%s/sendMessage?chat_id=%s&text=%s'
    slack_endpoint = 'https://slack.com/api/chat.postMessage'
    snapchat_endpoint = ''
    whatapp_endpoint = ''
    email_smtp_api = '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'
    from_email = 'pomprawit@hotmail.com'
    twilio_tmp_telno = "+13206266104"

    lineApi = None
    telegramApi = None
    telegramChatId = None
    slackApi = None
    snapChatApi = None
    whatAppApi = None
    email = None
    smsTelno = None
    twilioAccountId = None
    twilioAuthToken = None

    def __init__(self):
        pass

    # receive api
    def setLineApi(self, api):
        self.lineApi = api

    # receive api, chat id
    def setTelegramApi(self, *args):
        self.telegramApi = args[0]
        self.telegramChatId = args[1]

    def setSlackApi(self, api):
        self.slackApi = api

    def setSnapChatApi(self, api):
        self.snapChatApi = api

    def setWhatAppApi(self, api):
        self.whatAppApi = api

    def setEmail(self, email):
        self.email = email

    def setSmsTelno(self, telno):
        self.smsTelno = telno

    def setTwilioAccountId(self, accountId):
        self.twilioAccountId = accountId

    def setTwilioAuthToken(self, token):
        self.twilioAuthToken = token

    def sendAllNotification(self, msg):
        # send line noti.
        try:
            self.sendLine(msg)
        except Exception as e:
            print(e)

        try:
            self.sendTelegram(msg)
        except Exception as e:
            print(e)

        try:
            self.sendSlack(msg)
        except Exception as e:
            print(e)

        try:
            self.sendEmail(msg)
        except Exception as e:
            print(e)

        try:
            self.sendSMSTelNo(msg)
        except Exception as e:
            print(e)

    def sendLine(self, msg):
        # send line noti.
        try:
            print("Inside send line notification.")
            if self.lineApi == '':
                raise Exception("Line Api is invalid")
            print(f"line api key::{self.lineApi}")
            payload = {'message': msg}
            requests.post(
                self.line_endpoint, headers={'Authorization': 'Bearer {}'.format(self.lineApi)}, params=payload
            )
        except Exception as e:
            print("Error send line noti.:", e)

    def sendTelegram(self, msg):
        # send telegram
        try:
            if self.telegramApi == '':
                raise Exception("Telegram Api is invalid")

            if self.telegramChatId == '':
                raise Exception("Telegram Chat Id. is invalid")

            url = self.telegram_endpoint % (self.telegramApi, self.telegramChatId, msg)
            requests.get(url, timeout=10)
        except Exception as e:
            print("Error send telegram noti.:", e)

    def sendSlack(self, msg):
        # send slack noti.
        try:

            if self.slackApi == '':
                raise Exception("Slack Api is invalid")

            blocks = [
                {
                    "type": "section",
                    "text": {"type": "mrkdwn", "text": ":check: The script has run successfully on the dev."},
                }
            ]

            payload = {
                'token': '',
                'channel': '',
                'text': msg,
                'icon_emoji': None,
                'username': '',
                'blocks': json.dumps(blocks) if blocks else None,
            }
            requests.post(
                self.slack_endpoint, headers={'Authorization': 'Bearer {}'.format(self.slackApi)}, params=payload
            )
        except Exception as e:
            print("Error send slack noti.:", e)

    def sendEmail(self, msg):
        # send noti. to email
        try:
            if self.email == '':
                raise Exception("Email is invalid")
            # send email message to sendgrid mail server
            message = Mail(
                from_email=self.from_email,
                to_emails=self.email,
                subject='Sending with DeepOcean',
                html_content=f'<strong>{msg}</strong>',
            )

            sg = SendGridAPIClient(self.email_smtp_api)
            response = sg.send(message)
            print("Send email response: " + response)
        except Exception as e:
            print("Error send email noti.:", e)

    def sendSMSTelNo(self, msg):
        # send noti. to telephone
        try:
            if self.smsTelno == '':
                raise Exception("SMS Telephone no. is invalid")

            if self.twilioAccountId == '':
                raise Exception("Twilio Account ID. is invalid")

            if self.twilioAuthToken == '':
                raise Exception("Twilio Auth Token is invalid")

            client = Client(self.twilioAccountId, self.twilioAuthToken)

            message = client.messages.create(body=msg, from_=self.twilio_tmp_telno, to=f'+{self.smsTelno}')

            print("Send SMS Tel no. response:", message)
        except Exception as e:
            print("Error send sms telephone noti.:", e)
