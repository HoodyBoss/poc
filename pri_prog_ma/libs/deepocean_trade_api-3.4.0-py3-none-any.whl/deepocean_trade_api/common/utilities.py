import json
import os
import sys
from datetime import datetime as dt

import pandas as pd
import requests

# initial logging
from deepocean_trade_api.common import DOLogger
from deepocean_trade_api.common.config import ConfigManager

_config = ConfigManager()
_config = _config.load_config()
mode = _config["mode"]
log_name = "DEEPOCEAN_GCP_UTILS"
logger = DOLogger(_env=mode, log_name=log_name, level=_config["logs"]["level"])


GCLOUD_PROJECT = os.getenv("CLOUD_PROJECT_ID")
BUCKET_NAME = os.getenv("BUCKET_NAME")
LINE_NOTI_ENDPOINT = os.getenv("LINE_NOTI_ENDPOINT")
BACKEND_API_GATEWAY_ENDPOINT = os.getenv("BACKEND_API_GATEWAY_ENDPOINT")
BACKEND_API_GATEWAY_APIKEY = os.getenv("BACKEND_API_GATEWAY_APIKEY")
NOTIFICATION_PUBSUB_TOPIC = os.getenv("NOTIFICATION_PUBSUB_TOPIC")


class DOUtilities:
    html_escape_table = {
        "&": "[ampersand]",
        '"': "[quotation]",
        "'": "[apos]",
        ">": "[greater_than]",
        "<": "[less_than]",
        "+": "[plus]",
        "-": "[minus]",
        "÷": "[division]",
    }

    html_unescape_table = {
        "[ampersand]": "&",
        "[quotation]": '"',
        "[apos]": "'",
        "[greater_than]": ">",
        "[less_than]": "<",
        "[plus]": "+",
        "[minus]": "-",
        "[division]": "÷",
    }

    def html_escape(self, text):
        """Produce entities within text."""
        return "".join(self.html_escape_table.get(c, c) for c in text)

    def html_unescape(self, text):
        """Produce entities within text."""
        return [text.replace(k, v) for k, v in self.html_unescape_table.items() if text != text.replace(k, v)]

    def write_firestore(self, **kwargs):
        from google.cloud import firestore

        db = firestore.Client()
        now = dt.now()
        cur_time = now.strftime("%Y%m%d%H%M%S%f")

        path = kwargs["path"]
        df = kwargs["df"]
        doc_name = kwargs["doc_name"]
        # add create time to data
        df.update({"cd": cur_time})

        if not doc_name:
            db.collection(path).add(df)
        else:
            # create document in collection path
            db.collection(path).document(doc_name).set(df)

    def update_firestore(self, **kwargs):
        from google.cloud import firestore

        db = firestore.Client()
        now = dt.now()
        cur_time = now.strftime("%Y%m%d%H%M%S%f")

        path = kwargs["path"]
        df = kwargs["df"]
        doc_name = kwargs["doc_name"]
        # add create time to data
        df.update({"cd": cur_time})

        db.collection(path).document(doc_name).update(df)

    def send_admin_line(self, line_token_api, payload):
        try:
            requests.post(
                LINE_NOTI_ENDPOINT, headers={'Authorization': 'Bearer {}'.format(line_token_api)}, params=payload
            )

        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            logger.error(f'-send_line. Error: {e}, Line no.:{exc_tb.tb_lineno}')

    def get_secret_by_apikey(self, apiKey):
        # Import the Secret Manager client library.
        try:
            url = f'{BACKEND_API_GATEWAY_ENDPOINT}/getTradeApi'
            secret = requests.post(
                url,
                json={"apiKey": apiKey},
                headers={"Content-Type": "application/json", "x-api-key": BACKEND_API_GATEWAY_APIKEY},
            )
            return secret.text
        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            logger.error(f'-get_secret_by_apikey. Error: {e}, Line no.:{exc_tb.tb_lineno}')
            return

    # push pubsub
    def push_notificatoin_pubsub(self, json_data):
        # Instantiates a Pub/Sub client
        from google.cloud import pubsub_v1

        publisher = pubsub_v1.PublisherClient()
        topic_path = publisher.topic_path(GCLOUD_PROJECT, NOTIFICATION_PUBSUB_TOPIC)
        message_json = json.dumps(
            {
                'data': {'message': json_data},
            }
        )
        message_bytes = message_json.encode('utf-8')
        # Publishes a message
        try:
            publish_future = publisher.publish(topic_path, data=message_bytes)
            publish_future.result()  # Verify the publish succeeded
            return 'Message published.'
        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            logger.error(f'GCP utilities. Error: {e}, Line no.:{exc_tb.tb_lineno}')
            raise Exception(e)

    # common function to push pubsub
    def push_any_pubsub(self, project_id, pubsub_topic, json_data):
        # Instantiates a Pub/Sub client
        from google.cloud import pubsub_v1

        publisher = pubsub_v1.PublisherClient()
        topic_path = publisher.topic_path(project_id, pubsub_topic)
        message_json = json.dumps(
            {
                'data': {'message': json_data},
            }
        )
        message_bytes = message_json.encode('utf-8')
        # Publishes a message
        try:
            publish_future = publisher.publish(topic_path, data=message_bytes)
            publish_future.result()  # Verify the publish succeeded
            return 'Message published.'
        except Exception as e:
            raise Exception(e)

    def write_csv_to_tmp(self, df, file_name):
        df.to_csv('/tmp/' + file_name + '.csv', index=False)

    def upload_csv_to_storage(self, prefix, csv_file_name):
        from google.cloud import storage

        try:
            # path to keep file by each account on cloud storage
            if mode == "live":
                dest_file = f'{prefix}/{csv_file_name}'
                source_csv_file = f'/tmp/{csv_file_name}'

                pd.read_csv(
                    os.path.join('/tmp/', csv_file_name),
                )
                # Upload to Google cloud storage
                client = storage.Client()
                bucket = client.get_bucket(BUCKET_NAME)
                blob = bucket.blob(dest_file)
                blob.upload_from_filename(source_csv_file)
            else:
                pass
        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            logger.error(f'upload_csv_to_storage. Error: {e}, Line no.:{exc_tb.tb_lineno}')
            return None

    def upload_excel_to_storage(self, prefix, excel_file_name):
        from google.cloud import storage

        try:
            # path to keep file by each account on cloud storage
            if mode == "live":
                dest_file = f'{prefix}/{excel_file_name}'
                source_xls_file = f'/tmp/{excel_file_name}'

                pd.read_excel(
                    os.path.join('/tmp/', excel_file_name),
                )
                # Upload to Google cloud storage
                client = storage.Client()
                bucket = client.get_bucket(BUCKET_NAME)
                blob = bucket.blob(dest_file)
                blob.upload_from_filename(source_xls_file)
            else:
                pass
        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            logger.error(f'upload_excel_to_storage. Error: {e}, Line no.:{exc_tb.tb_lineno}')
            return None

    # #xls_file = excel file in cloud storage bucket
    def download_csv_from_storage(self, prefix, csv_file):
        import io

        from google.cloud import storage

        try:
            blob_name = f"{prefix}/{csv_file}"

            storage_client = storage.Client()
            bucket = storage_client.bucket(BUCKET_NAME)
            blob = bucket.blob(blob_name)

            data_bytes = blob.download_as_bytes()

            df = pd.read_csv(io.BytesIO(data_bytes), encoding='utf8')
            return df
        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            logger.error(f'download_csv_from_storage. Error: {e}, Line no.:{exc_tb.tb_lineno}')
            return None

    # #xls_file = excel file in cloud storage bucket
    def download_excel_from_storage(self, prefix, excel_file):

        from google.cloud import storage

        try:
            blob_name = f"{prefix}/{excel_file}"

            storage_client = storage.Client()
            bucket = storage_client.bucket(BUCKET_NAME)
            blob = bucket.blob(blob_name)

            data_bytes = blob.download_as_bytes()

            df = pd.read_excel(data_bytes)

            return df
        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            logger.error(f'download_csv_from_storage. Error: {e}, Line no.:{exc_tb.tb_lineno}')
            return None

    # #read file from cloud storage then write file to /tmp path in cloud function
    def prepare_csv_file_for_running(self, csv_path, csv_file_name):
        try:
            if mode == "live":
                df = self.download_csv_from_storage(csv_path, csv_file_name)
                # df.to_csv(f'/tmp/{xls_file_name}')
                df.to_csv(f'/tmp/{csv_file_name}')
            else:
                pass
        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            logger.error(f'prepare_csv_file_for_running. Error: {e}, Line no.:{exc_tb.tb_lineno}')

    def prepare_excel_file_for_running(self, xls_path, xls_file_name):
        if mode == "live":
            from google.cloud import storage

            try:
                blob_name = f'{xls_path}/{xls_file_name}'
                storage_client = storage.Client()
                bucket = storage_client.bucket(BUCKET_NAME)
                blob = bucket.blob(blob_name)

                data_bytes = blob.download_as_bytes()

                df = pd.read_excel(data_bytes)
                df.to_excel(f'/tmp/{xls_file_name}')
            except Exception as e:
                exc_type, exc_obj, exc_tb = sys.exc_info()
                logger.error(f'prepare_excel_file_for_running. Error: {e}, Line no.:{exc_tb.tb_lineno}')
        else:
            pass

    # #save file back to cloud storage from /tmp path
    def backup_csv_to_storage(self, prefix, csv_file_name):
        self.upload_csv_to_storage(prefix, csv_file_name)

    # #save file back to cloud storage from /tmp path
    def backup_excel_to_storage(self, prefix, excel_file_name):
        self.upload_excel_to_storage(prefix, excel_file_name)

    def determine_timeDelta(self, frequency, frequencyMultiple):
        import datetime
        frequencies = ["hours", "days", "weeks"]

        if frequency in frequencies:
            kwargs = {frequency: frequencyMultiple}
        else:
            kwargs = {"days": 1}

        return datetime.timedelta(**kwargs)