# Imports the Google Cloud client library
import logging
from datetime import datetime as dt
from logging.handlers import TimedRotatingFileHandler

import google.cloud.logging
import structlog
from google.cloud.logging.handlers import CloudLoggingHandler
from google.logging.type import log_severity_pb2 as severity

structlog.configure(processors=[structlog.processors.JSONRenderer()])


class DOLogger:

    ENV = 'local'
    NAME = ''
    LEVEL = 'DEBUG'
    glogger = None
    logging_client = None
    log = None
    live = 'live'
    time_format = "%Y%m%d%H%M%S-%f"

    # log level
    CRITICAL = 50
    FATAL = CRITICAL
    ERROR = 40
    WARNING = 30
    WARN = WARNING
    INFO = 20
    DEBUG = 10
    NOTSET = 0
    ALERT = 700

    # # Create a handler for Google Cloud Logging.
    gcloud_logging_client = None
    gcloud_logging_handler = None
    glogger = None

    # Create a stream handler to log messages to the console.
    stream_handler = None
    rotatefile_handler = None

    # Now create a logger and add the handlers:
    logger = None

    def __init__(self, _env="local", log_name='DeepOcean', level="NOTSET"):
        # Instantiates a client
        self.log = structlog.get_logger()
        self.ENV = _env
        self.NAME = log_name
        # Create a stream handler to log messages to the console.
        self.stream_handler = logging.StreamHandler()

        if level == "NOTSET":
            level = self.NOTSET
        elif level == "DEBUG":
            level = self.DEBUG
        elif level == "INFO":
            level = self.INFO
        elif level == "WARNING":
            level = self.WARNING
        elif level == "ERROR":
            level = self.ERROR
        elif level == "CRITICAL":
            level = self.CRITICAL
        elif level == "FATAL":
            level = self.FATAL

        self.stream_handler.setLevel(level)

        # Now create a logger and add the handlers:

        # if run on localhost or any server know as local, add rolling file handlers
        if self.ENV == "local":
            self.logger = logging.getLogger(log_name)
            self.logger.setLevel(level)
            self.logger.addHandler(self.stream_handler)

            # queue handlers
            # self.log_queue     = queue.Queue()
            # self.queue_handler = QueueHandler(self.log_queue)  # Non-blocking handler.
            # self.logger.addHandler(self.queue_handler)

            # queue_listener1 = QueueListener(self.log_queue,
            #                        self.stream_handler)
            # queue_listener1.start()

            self.rotatefile_handler = TimedRotatingFileHandler(
                "DO_SystemOut.log", when='D', interval=1, backupCount=30, delay=True
            )
            self.logger.addHandler(self.rotatefile_handler)

            # self.mem_handler = MemoryHandler(capacity=4092)
            # self.logger.addHandler(self.mem_handler)
            # queue_listener = QueueListener(self.log_queue,
            #                    self.rotatefile_handler)
            # queue_listener.start()

        # add google handeler if this log run on google cloud
        if self.ENV == "live":
            self.logger = logging.getLogger(log_name)
            self.logger.setLevel(level)
            self.logger.addHandler(self.stream_handler)

            self.gcloud_logging_client = google.cloud.logging.Client()
            self.gcloud_logging_handler = CloudLoggingHandler(self.gcloud_logging_client, name=log_name)
            self.glogger = self.gcloud_logging_client.logger(log_name)
            self.NAME = log_name
            self.logger.addHandler(self.gcloud_logging_handler)

    def setLogName(self, log_name):
        self.logger = self.logging_client.logger(log_name)
        self.NAME = log_name

    def setEnv(self, env):
        self.ENV = env

    def setLevel(self, level):
        self.LEVEL = level

    def flush(self):
        self.mem_handler.setTarget(self.rotatefile_handler)
        self.mem_handler.flush()

    # log info here
    def info(self, msg):
        import time

        if self.ENV == self.live:
            if self.NAME == '':
                raise Exception('Log name empty. please set log name.')
        now = dt.now()
        tstr = now.strftime(self.time_format)
        # log to logging object but also add google handler
        time.sleep(3)
        self.logger.info({'log_time': tstr, 'log_name': self.NAME, 'log_level': 'INFO', 'log_message': msg})

    def debug(self, msg):
        if self.ENV == self.live:
            if self.NAME == '':
                raise Exception('Log name empty. please set log name.')
        now = dt.now()
        tstr = now.strftime(self.time_format)
        self.logger.debug({'log_time': tstr, 'log_name': self.NAME, 'log_level': 'DEBUG', 'log_message': msg})

    def error(self, msg):
        if self.ENV == self.live:
            if self.NAME == '':
                raise Exception('Log name empty. please set log name.')
        now = dt.now()
        tstr = now.strftime(self.time_format)
        self.logger.error({'log_time': tstr, 'log_name': self.NAME, 'log_level': 'ERROR', 'log_message': msg})

    def warning(self, msg):
        if self.ENV == self.live:
            if self.NAME == '':
                raise Exception('Log name empty. please set log name.')
        now = dt.now()
        tstr = now.strftime(self.time_format)
        self.logger.warning({'log_time': tstr, 'log_name': self.NAME, 'log_level': 'WARNING', 'log_message': msg})

    def critical(self, msg):
        if self.ENV == self.live:
            if self.NAME == '':
                raise Exception('Log name empty. please set log name.')
        now = dt.now()
        tstr = now.strftime(self.time_format)
        self.logger.critical({'log_time': tstr, 'log_name': self.NAME, 'log_level': 'CRITICAL', 'log_message': msg})

    def alert(self, msg):
        if self.ENV == self.live:
            if self.NAME == '':
                raise Exception('Log name empty. please set log name.')

            now = dt.now()
            tstr = now.strftime(self.time_format)
            self.glogger.log_text(
                str({'log_time': tstr, 'log_name': self.NAME, 'log_level': 'ALERT', 'log_message': msg}),
                severity=severity.ALERT,
            )
