# define Python user-defined exceptions
class Error(Exception):
    """Base class for other exceptions"""

    def __init__(self, error_msg):
        super().__init__(self.error_msg)


class ValueTooSmallError(Error):
    """Raised when the input value is too small"""

    def __init__(self, error_msg):
        super().__init__(self.error_msg)


class ValueTooLargeError(Error):
    """Raised when the input value is too large"""

    def __init__(self, error_msg):
        super().__init__(self.error_msg)


class DOBusinessError(Error):
    """Raised when found business error"""

    def __init__(self, error_msg):
        super().__init__(self.error_msg)


class DOInfrastuctureError(Error):
    """Raised when found infra. error"""

    def __init__(self, error_msg):
        super().__init__(self.error_msg)
