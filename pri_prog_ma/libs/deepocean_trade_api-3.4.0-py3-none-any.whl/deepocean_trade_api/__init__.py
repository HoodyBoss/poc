from enum import Enum

TIME_FORMAT = "%Y%m%d%H%M%S-%f"
SIGNAL_TIME_FORMAT = "%Y-%m-%d %H:%M:%S"


class TradeType(str, Enum):
    MARKET = 'MARKET'
    LIMIT = 'LIMIT'
    STOPLOSS = 'STOPLOSS'
    TAKEPROFIT = 'TAKEPROFIT'
    STOPLOSS_TRAILING = 'STOPLOSS_TRAILING'
    AT_THE_OPEN = 'ATO'
    MARKET_TO_LIMIT_ORDER = 'MP-MTL'
    MARKET_ORDER = 'MP-MKT'

    def __str__(self):
        return self.value


# convert string trade type data to fit each market
class TradeTypeConverter:
    def __init__(self):
        pass

    @staticmethod
    def get_tradetype_stt(tradetype: str) -> str:
        if tradetype == TradeType.MARKET.value:
            return "MP"
        else:
            return tradetype


class Side(str, Enum):
    BUY = 'BUY'
    SELL = 'SELL'
    LONG_OPEN = 'LONG_OPEN'
    LONG_CLOSE = 'LONG_CLOSE'
    SHORT_OPEN = 'SHORT_OPEN'
    SHORT_CLOSE = 'SHORT_CLOSE'

    def __str__(self):
        return self.value


class PositionSizeType(str, Enum):
    UNIT = '1'
    PERCENTAGE = '2'
    MONEY = '3'

    def __str__(self):
        return self.value


# convert string side data to fit each market
class SideConverter:
    def __init__(self):
        pass

    # return side, position
    @staticmethod
    def get_side_position(side: str):
        if side == Side.BUY.value:
            return "BUY", ""
        elif side == Side.SELL.value:
            return "SELL", ""
        elif side == Side.LONG_OPEN.value:
            return "LONG", "OPEN"
        elif side == Side.LONG_CLOSE.value:
            return "LONG", "CLOSE"
        elif side == Side.SHORT_OPEN.value:
            return "SHORT", "OPEN"
        elif side == Side.SHORT_CLOSE.value:
            return "SHORT", "CLOSE"


class MandatoryField(Enum):
    symbol = "symbol"
    trade_type = "trade_type"
    side = "side"
    position_size = "position_size"


class CorrelationStatus(str, Enum):
    CREATED = 'CREATED'
    CANCELLED = 'CANCELLED'

    def __str__(self):
        return self.value


class TradeStatus(str, Enum):
    INITIAL = 'INITIAL'
    PENDING = 'PENDING'
    OPENED = 'OPENED'
    CLOSED = 'CLOSED'
    CANCELLED = 'CANCELLED'

    def __str__(self):
        return self.value
