import os

from cryptography.fernet import Fernet

# key generation
key = os.getenv("DO_KEY")

# using the generated key
fernet = Fernet(str(key))

# opening the original file to encrypt
with open('3f7fb75bc3cb.json', 'rb') as file:
    original = file.read()

# encrypting the file
encrypted = fernet.encrypt(original)

# opening the file in write mode and
# writing the encrypted data
with open('encrypt.json', 'wb') as encrypted_file:
    encrypted_file.write(encrypted)
