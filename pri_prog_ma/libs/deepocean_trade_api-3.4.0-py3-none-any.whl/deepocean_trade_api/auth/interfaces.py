from abc import ABCMeta, abstractmethod


class AuthorizationInterface:
    __metaclass__ = ABCMeta

    @abstractmethod
    def send_signal(self, signal: dict) -> str:
        pass

    @abstractmethod
    def validate_var(self):
        pass

    @abstractmethod
    def make_request(self, url: str, signal_data: dict) -> str:
        pass
