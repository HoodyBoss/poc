from abc import ABCMeta, abstractmethod

from deepocean_trade_api import MandatoryField, Side, TradeType


class Validator:
    __metaclass__ = ABCMeta

    @abstractmethod
    def validate(self, data: dict) -> bool:
        pass


class MandatoryFileValidator(Validator):
    def validate(self, signal_data: dict):
        result = [k in signal_data.keys() for k in [x.value for x in MandatoryField]]
        return all(result)


class TradeTypeValidator(Validator):
    def validate(self, signal_data: dict):
        # find the same value from signal data in TradeType enum
        result = [True for k in [x.value for x in TradeType] if k == signal_data.get(MandatoryField.trade_type.value)]
        return False if not result else True


class SideValidator(Validator):
    def validate(self, signal_data: dict):
        # find the same value from signal data in Side enum
        result = [True for k in [x.value for x in Side] if k == signal_data.get(MandatoryField.side.value)]
        return False if not result else True


# A class which validate all information in signal data which send from client
class DeepOceanSignalSchemaValidator:

    _signal_data = None

    _mandatoryFieldValidator = MandatoryFileValidator()
    _sideValidator = SideValidator()
    _tradeTypeValidator = TradeTypeValidator()

    def __init__(self, signal_data: dict):
        self._signal_data = signal_data

    def validate(self):

        # validate mandatory fields in signal data
        if not self._mandatoryFieldValidator.validate(self._signal_data):
            raise Exception(f"Signal data invalid mandatory field. {self._signal_data}")

        # validate trade type value in signal data
        if not self._tradeTypeValidator.validate(self._signal_data):
            raise Exception(f"Signal data invalid trade type value. {self._signal_data}")

        # validate side value in signal data
        if not self._sideValidator.validate(self._signal_data):
            raise Exception(f"Signal data invalid side value. {self._signal_data}")

        # validate position size
        position_size = self._signal_data["position_size"]

        if position_size is None:
            raise Exception("Signal data position_size value. position_size cannot be None")

        if type(position_size) != float:
            raise Exception("Signal data position_size value. position_size should be a float")
