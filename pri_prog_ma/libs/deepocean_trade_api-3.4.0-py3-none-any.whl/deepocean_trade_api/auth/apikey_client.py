#!/usr/bin/env python

# Copyright 2016 Google Inc. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Example of calling a Google Cloud Endpoint API with a JWT signed by
a Google API Service Account."""

import os
import sys
import time
import uuid
from datetime import datetime as dt

import requests

from deepocean_trade_api import SIGNAL_TIME_FORMAT
from deepocean_trade_api.auth.validator import DeepOceanSignalSchemaValidator
from deepocean_trade_api.common import DOLogger
from deepocean_trade_api.common.config import ConfigManager


class APIKeyAuthorization:

    # initial logger
    _logger = None
    _strategy_id = None
    _config = None
    headers = {'Content-Type': 'application/json', 'x-api-key': os.getenv("DO_KEY")}

    def __init__(self, strategy_id: str):

        self._strategy_id = strategy_id
        self._config = ConfigManager()
        self._config = self._config.load_config()

        self._logger = DOLogger(
            _env=self._config["logs"]["env"],
            log_name=f"CLIENT_SIGNAL_{strategy_id}",
            level=self._config["logs"]["level"],
        )

    # [START endpoints_apikey_request]
    def make_request(self, url, json_data):
        """Makes an authorized request to the endpoint"""
        now = dt.now()
        tstr = now.strftime(SIGNAL_TIME_FORMAT)
        try:
            # additional data
            signal_data = {}
            signal_data.update({"correlation_id": str(uuid.uuid1())})
            signal_data.update({"exchange_id": self._config['exchange']['exchange_id']})
            signal_data.update({"strategy_id": self._strategy_id})
            signal_data.update({"datetime": tstr})
            signal_data.update({"signal": json_data})

            self._logger.info(f"Signal Data:{signal_data}")

            response = requests.post(url, json=signal_data, headers=self.headers)

            return response.status_code
        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            self._logger.error(f"{e}. Line no. :{exc_tb.tb_lineno}")
            raise Exception("ERROR 500. internal server error. please contact admin.")

    # [END endpoints_apikey_request]

    # validate system variable here
    def validate_var(self):

        if not self._strategy_id:
            raise Exception("strategy id not exist. Please initial object by strategy id constructor")

        host = os.getenv("DO_HOST")
        if not host:
            raise Exception("DO_HOST not exist in system variable. Please set it.")

        key = os.getenv("DO_KEY")
        if not key:
            raise Exception("DO_KEY not exist in system variable. Please set it.")

    def send_signal(self, **_signal_data):
        import json

        start = time.time()
        try:

            # validate system variable first
            self.validate_var()

            # call signal schema validator here
            # if found error, the exeception will raise from there
            signalSchemaValidator = DeepOceanSignalSchemaValidator(_signal_data)
            signalSchemaValidator.validate()

            # process json data here
            try:
                json_data = _signal_data
                if isinstance(_signal_data, str):
                    json_data = json.loads(_signal_data)

            except Exception:
                exc_type, exc_obj, exc_tb = sys.exc_info()
                self._logger.error(f"Signal data invalid json format. {json_data}")
                raise Exception(f"Signal data invalid json format. {json_data}")

            HOST = os.getenv("DO_HOST")
            host = f"{HOST}/api/v1/signal/{self._config['exchange']['exchange_id']}?time={time.time()}"

            # call create signal data and post to api
            ret_code = self.make_request(host, json_data)

            end = time.time()
            print("Process time::", round(end - start), 's')
            return ret_code

        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            self._logger.error(f"{e}. Line no. :{exc_tb.tb_lineno}")
            raise Exception(f"{e}. Line no. :{exc_tb.tb_lineno}")
