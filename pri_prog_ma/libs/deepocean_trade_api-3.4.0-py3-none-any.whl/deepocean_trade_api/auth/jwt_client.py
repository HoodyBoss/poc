#!/usr/bin/env python

# Copyright 2016 Google Inc. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Example of calling a Google Cloud Endpoint API with a JWT signed by
a Google API Service Account."""

import json
import os
import sys
import time
import uuid
from datetime import datetime as dt

import google.auth.crypt
import google.auth.jwt
import requests
from cryptography.fernet import Fernet

from deepocean_trade_api import SIGNAL_TIME_FORMAT
from deepocean_trade_api.auth.validator import DeepOceanSignalSchemaValidator
from deepocean_trade_api.common import DOLogger
from deepocean_trade_api.common.config import ConfigManager


class JWTAuthorization:

    _logger = None
    _strategy_id = None
    _config = None

    def __init__(self, strategy_id: str):
        self._strategy_id = strategy_id
        self._config = ConfigManager()
        self._config = self._config.load_config()

        self._logger = DOLogger(
            _env=self._config["logs"]["env"],
            log_name=f"CLIENT_SIGNAL_{strategy_id}",
            level=self._config["logs"]["level"],
        )

    # [START endpoints_generate_jwt_sa]
    def generate_jwt(self, sa_email, audience='', expiry_length=3600):

        """Generates a signed JSON Web Token using a Google API Service Account."""

        now = int(time.time())

        # build payload
        payload = {
            'iat': now,
            # expires after 'expiry_length' seconds.
            "exp": now + expiry_length,
            # iss must match 'issuer' in the security configuration in your
            # swagger spec (e.g. service account email). It can be any string.
            'iss': sa_email,
            # aud must be either your Endpoints service name, or match the value
            # specified as the 'x-google-audience' in the OpenAPI document.
            'aud': audience,
            # sub and email should match the service account's email address
            'sub': sa_email,
            'email': sa_email,
        }

        # this key is generate from fernet original from admin generate key for encrypt json file
        key = os.getenv("DO_KEY")
        fernet = Fernet(key)
        # decyrpt
        # opening the encrypted file
        with open('data', 'rb') as enc_file:
            encrypted = enc_file.read()

        # decrypting file content
        decrypted = fernet.decrypt(encrypted)

        # sign with encrypt content here
        prv_inf = json.loads(decrypted)

        signer = google.auth.crypt.RSASigner.from_service_account_info(prv_inf)

        jwt = google.auth.jwt.encode(signer, payload)

        return jwt

    # [END endpoints_generate_jwt_sa]

    # [START endpoints_jwt_request]
    def make_request(self, signed_jwt, url, json_data):
        now = dt.now()
        tstr = now.strftime(SIGNAL_TIME_FORMAT)
        try:
            """Makes an authorized request to the endpoint"""

            signal_data = {}
            signal_data.update({"correlation_id": str(uuid.uuid1())})
            signal_data.update({"exchange_id": self._config['exchange']['exchange_id']})
            signal_data.update({"strategy_id": self._strategy_id})
            signal_data.update({"datetime": tstr})
            signal_data.update({"signal": json_data})

            self._logger.info(f"Signal Data:{signal_data}")

            headers = {
                'Authorization': 'Bearer {}'.format(signed_jwt.decode('utf-8')),
                'content-type': 'application/json',
            }
            response = requests.post(url, json=signal_data, headers=headers)

            self._logger.info(f"Post signal response code:{response.status_code}, text: {response.text}")

            return response.status_code
        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            self._logger.error(f"{e}. Line no. :{exc_tb.tb_lineno}")
            raise Exception("ERROR 500. internal server error. please contact admin.")

    # [END endpoints_jwt_request]

    # validate system variable here
    def validate_var(self):
        host = os.getenv("DO_HOST")
        if not host:
            raise Exception("DO_HOST not exist in system variable. Please set it.")

        key = os.getenv("DO_KEY")
        if not key:
            raise Exception("DO_KEY not exist in system variable. Please set it.")

        sa = os.getenv("DO_EXTERNAL_SA")
        if not sa:
            raise Exception("DO_EXTERNAL_SA not exist in system variable. Please set it.")

        audience = os.getenv("DO_AUDIENCE")
        if not audience:
            raise Exception("DO_AUDIENCE not exist in system variable. Please set it.")

    def send_signal(self, **_signal_data):

        try:
            self._logger.info("#######################################Begin##########################################")
            self._logger.info("Initial send signal by api key")
            # validate system variable
            self.validate_var()

            # call signal schema validator here
            # if found error, the exeception will raise from there
            signalSchemaValidator = DeepOceanSignalSchemaValidator(_signal_data)
            signalSchemaValidator.validate()

            # process json data here
            try:
                json_data = _signal_data
                if isinstance(_signal_data, str):
                    json_data = json.loads(_signal_data)

            except Exception:
                exc_type, exc_obj, exc_tb = sys.exc_info()
                self._logger.error(f"Signal data invalid json format. {json_data}")
                raise Exception(f"Signal data invalid json format. {json_data}")

            # args = parser.parse_args()
            HOST = os.getenv("DO_HOST")
            host = f"{HOST}/api/v1/signal/{self._config['exchange']['exchange_id']}/jwt"
            sa_email = os.getenv("DO_EXTERNAL_SA")
            audience = os.getenv("DO_AUDIENCE")

            # try:
            #     requests.post(host, json={})
            # except:
            #     pass

            expiry_length = 3600
            keyfile_jwt = self.generate_jwt(sa_email, audience, expiry_length)

            ret_code = self.make_request(keyfile_jwt, host, json_data)
            self._logger.info("#########################################End#########################################")
            return ret_code

        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            self._logger.error(f"{e}. Line no. :{exc_tb.tb_lineno}")
            raise Exception(f"ERROR: {e}. Line no. :{exc_tb.tb_lineno}")
